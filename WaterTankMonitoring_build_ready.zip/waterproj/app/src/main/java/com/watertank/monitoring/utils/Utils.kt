package com.watertank.monitoring.utils

import android.content.Context
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.graphics.vector.ImageVector
import java.text.SimpleDateFormat
import java.util.*

// ============================================
// Date & Time Utilities
// ============================================

fun Date.formatTime(): String {
    val now = Date()
    val diff = now.time - this.time
    val seconds = diff / 1000
    val minutes = seconds / 60
    val hours = minutes / 60
    val days = hours / 24
    
    return when {
        seconds < 60 -> "Just now"
        minutes == 1L -> "1 minute ago"
        minutes < 60 -> "$minutes minutes ago"
        hours == 1L -> "1 hour ago"
        hours < 24 -> "$hours hours ago"
        days == 1L -> "1 day ago"
        days < 7 -> "$days days ago"
        else -> SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(this)
    }
}

fun Date.formatFull(): String {
    return SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(this)
}

fun Date.formatTime24(): String {
    return SimpleDateFormat("HH:mm", Locale.getDefault()).format(this)
}

fun Long.toDate(): Date = Date(this)

fun Long.formatTime(): String = Date(this).formatTime()

// ============================================
// Water Level Utilities
// ============================================

fun Int.getWaterLevelStatus(): String {
    return when {
        this >= 90 -> "Full"
        this >= 70 -> "High"
        this >= 50 -> "Normal"
        this >= 30 -> "Low"
        else -> "Critical"
    }
}

fun Int.getWaterLevelColor(): androidx.compose.ui.graphics.Color {
    return when {
        this >= 90 -> androidx.compose.ui.graphics.Color(0xFFFF6B6B) // Red
        this >= 70 -> androidx.compose.ui.graphics.Color(0xFF51CF66) // Green
        this >= 50 -> androidx.compose.ui.graphics.Color(0xFF4ECDC4) // Teal
        this >= 30 -> androidx.compose.ui.graphics.Color(0xFFFFA500) // Orange
        else -> androidx.compose.ui.graphics.Color(0xFFFF6B6B) // Red
    }
}

// ============================================
// Battery Status Utilities
// ============================================

fun Int.getBatteryStatus(): String {
    return when {
        this >= 80 -> "Excellent"
        this >= 60 -> "Good"
        this >= 40 -> "Fair"
        this >= 20 -> "Low"
        else -> "Critical"
    }
}

fun Int.getBatteryColor(): androidx.compose.ui.graphics.Color {
    return when {
        this >= 80 -> androidx.compose.ui.graphics.Color(0xFF51CF66) // Green
        this >= 60 -> androidx.compose.ui.graphics.Color(0xFF4ECDC4) // Teal
        this >= 40 -> androidx.compose.ui.graphics.Color(0xFFFFA500) // Orange
        else -> androidx.compose.ui.graphics.Color(0xFFFF6B6B) // Red
    }
}

// ============================================
// WiFi Signal Utilities
// ============================================

fun Int.getWiFiStatus(): String {
    return when (this) {
        5 -> "Excellent"
        4 -> "Very Good"
        3 -> "Good"
        2 -> "Fair"
        1 -> "Poor"
        else -> "No Signal"
    }
}

fun Int.getWiFiIcon(): ImageVector {
    return when (this) {
        5, 4, 3 -> androidx.compose.material.icons.Icons.Filled.SignalCellularAlt
        2 -> androidx.compose.material.icons.Icons.Filled.SignalCellular2Bar
        1 -> androidx.compose.material.icons.Icons.Filled.SignalCellular1Bar
        else -> androidx.compose.material.icons.Icons.Filled.SignalCellularOff
    }
}

// ============================================
// String Extensions
// ============================================

fun String.isValidEmail(): Boolean {
    val emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$".toRegex()
    return matches(emailRegex)
}

fun String.isValidPassword(): Boolean {
    // At least 8 characters, 1 uppercase, 1 lowercase, 1 digit
    return length >= 8 &&
            contains(Regex("[A-Z]")) &&
            contains(Regex("[a-z]")) &&
            contains(Regex("[0-9]"))
}

fun String.truncate(length: Int): String {
    return if (this.length > length) {
        this.substring(0, length) + "..."
    } else {
        this
    }
}

// ============================================
// Number Extensions
// ============================================

fun Int.toWaterLevelCm(tankHeightCm: Int): Int {
    return (tankHeightCm * this) / 100
}

fun Int.toWaterLevelPercentage(tankHeightCm: Int): Int {
    return (this * 100) / tankHeightCm
}

fun Double.roundTo(decimals: Int): Double {
    val multiplier = Math.pow(10.0, decimals.toDouble())
    return kotlin.math.round(this * multiplier) / multiplier
}

// ============================================
// Composable Extensions
// ============================================

class PhoneNumberVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val trimmed = if (text.text.length >= 10) text.text.substring(0, 10) else text.text
        var out = ""
        for (i in trimmed.indices) {
            out += trimmed[i]
            if (i == 2 || i == 5) out += " "
        }
        
        val numberOffsetTranslator = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                if (offset <= 2) return offset
                if (offset <= 5) return offset + 1
                if (offset <= 10) return offset + 2
                return 12
            }
            
            override fun transformedToOriginal(offset: Int): Int {
                if (offset <= 2) return offset
                if (offset <= 6) return offset - 1
                if (offset <= 11) return offset - 2
                return 10
            }
        }
        
        return TransformedText(AnnotatedString(out), numberOffsetTranslator)
    }
}

// ============================================
// Context Extensions
// ============================================

fun Context.getDeviceId(): String {
    return android.provider.Settings.Secure.getString(
        contentResolver,
        android.provider.Settings.Secure.ANDROID_ID
    )
}

fun Context.getDeviceInfo(): String {
    return "Android ${android.os.Build.VERSION.SDK_INT} (${android.os.Build.DEVICE})"
}

// ============================================
// Validation Utilities
// ============================================

object Validators {
    fun validateEmail(email: String): ValidationResult {
        return if (email.isBlank()) {
            ValidationResult.Error("Email is required")
        } else if (!email.isValidEmail()) {
            ValidationResult.Error("Invalid email format")
        } else {
            ValidationResult.Valid
        }
    }
    
    fun validatePassword(password: String): ValidationResult {
        return if (password.isBlank()) {
            ValidationResult.Error("Password is required")
        } else if (password.length < 8) {
            ValidationResult.Error("Password must be at least 8 characters")
        } else if (!password.isValidPassword()) {
            ValidationResult.Error("Password must contain uppercase, lowercase, and number")
        } else {
            ValidationResult.Valid
        }
    }
    
    fun validateTankName(name: String): ValidationResult {
        return if (name.isBlank()) {
            ValidationResult.Error("Tank name is required")
        } else if (name.length < 3) {
            ValidationResult.Error("Tank name must be at least 3 characters")
        } else {
            ValidationResult.Valid
        }
    }
    
    fun validateTankHeight(height: Int): ValidationResult {
        return if (height <= 0) {
            ValidationResult.Error("Tank height must be greater than 0")
        } else if (height > 5000) {
            ValidationResult.Error("Tank height seems too large")
        } else {
            ValidationResult.Valid
        }
    }
}

sealed class ValidationResult {
    object Valid : ValidationResult()
    data class Error(val message: String) : ValidationResult()
}

// ============================================
// Logging Utilities
// ============================================

object Logger {
    private const val TAG = "WaterTank"
    
    fun d(message: String) {
        android.util.Log.d(TAG, message)
    }
    
    fun e(message: String, throwable: Throwable? = null) {
        android.util.Log.e(TAG, message, throwable)
    }
    
    fun i(message: String) {
        android.util.Log.i(TAG, message)
    }
    
    fun w(message: String) {
        android.util.Log.w(TAG, message)
    }
}

// ============================================
// Constants
// ============================================

object Constants {
    const val API_BASE_URL = "https://api.watertank.com"
    const val CONNECT_TIMEOUT = 30L
    const val READ_TIMEOUT = 30L
    const val WRITE_TIMEOUT = 30L
    
    // Database
    const val DATABASE_NAME = "tank_monitoring_db"
    const val DB_VERSION = 1
    
    // Preferences
    const val PREF_NAME = "water_tank_prefs"
    const val PREF_AUTH_TOKEN = "auth_token"
    const val PREF_USER_ID = "user_id"
    const val PREF_USER_EMAIL = "user_email"
    
    // Notification
    const val NOTIFICATION_CHANNEL_ID = "tank_alerts"
    const val NOTIFICATION_CHANNEL_NAME = "Tank Alerts"
    
    // Sync
    const val SYNC_INTERVAL_MINUTES = 5
    const val CLEANUP_INTERVAL_DAYS = 30
    
    // Thresholds
    const val LOW_WATER_THRESHOLD = 30
    const val HIGH_WATER_THRESHOLD = 90
    const val LOW_BATTERY_THRESHOLD = 20
}
