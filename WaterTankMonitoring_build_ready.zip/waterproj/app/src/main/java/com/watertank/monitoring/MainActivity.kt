package com.watertank.monitoring

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.watertank.monitoring.ui.AddTankScreen
import com.watertank.monitoring.ui.AlertsScreen
import com.watertank.monitoring.ui.SettingsScreen
import com.watertank.monitoring.ui.theme.WaterTankTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WaterTankTheme {
                WaterTankAppContent()
            }
        }
    }
}

@Composable
fun WaterTankAppContent() {
    val navController = rememberNavController()
    var isLoggedIn by remember { mutableStateOf(false) }
    var currentUser by remember { mutableStateOf<String?>(null) }
    
    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginScreen(
                onLoginSuccess = { userId ->
                    isLoggedIn = true
                    currentUser = userId
                    navController.navigate("dashboard") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate("register")
                }
            )
        }
        
        composable("register") {
            RegisterScreen(
                onRegisterSuccess = { userId ->
                    isLoggedIn = true
                    currentUser = userId
                    navController.navigate("dashboard") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    navController.popBackStack()
                }
            )
        }
        
        composable("dashboard") {
            MainScreen(navController, currentUser ?: "")
        }
    }
}

@Composable
fun MainScreen(navController: NavHostController, userId: String) {
    var selectedTab by remember { mutableStateOf(0) }
    
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Filled.Home, "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Filled.AddCircle, "Add") },
                    label = { Text("Add Tank") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Filled.Notifications, "Alerts") },
                    label = { Text("Alerts") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Filled.Settings, "Settings") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> DashboardScreen(userId)
                1 -> AddTankScreen()
                2 -> AlertsScreen()
                3 -> SettingsScreen()
            }
        }
    }
}

// Login Screen
@Composable
fun LoginScreen(
    onLoginSuccess: (String) -> Unit,
    onNavigateToRegister: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Logo/Title
        Icon(
            Icons.Filled.Waves,
            contentDescription = "App Logo",
            modifier = Modifier.size(80.dp),
            tint = Color(0xFF0066CC)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            "Water Tank Monitor",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1A1A1A)
        )
        
        Text(
            "Smart monitoring at your fingertips",
            fontSize = 14.sp,
            color = Color(0xFF666666),
            modifier = Modifier.padding(top = 8.dp)
        )
        
        Spacer(modifier = Modifier.height(40.dp))
        
        // Email Field
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Password Field
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Login Button
        Button(
            onClick = { 
                isLoading = true
                // Simulate API call
                onLoginSuccess("user_123")
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF0066CC)
            )
        ) {
            Text("Login", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Register Link
        Row {
            Text("Don't have an account? ", color = Color(0xFF666666))
            TextButton(onClick = onNavigateToRegister) {
                Text("Register", color = Color(0xFF0066CC))
            }
        }
    }
}

// Register Screen
@Composable
fun RegisterScreen(
    onRegisterSuccess: (String) -> Unit,
    onNavigateToLogin: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Create Account",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1A1A1A)
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Full Name") },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = { onRegisterSuccess("user_123") },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF0066CC)
            )
        ) {
            Text("Register", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Row {
            Text("Already have an account? ", color = Color(0xFF666666))
            TextButton(onClick = onNavigateToLogin) {
                Text("Login", color = Color(0xFF0066CC))
            }
        }
    }
}

// Dashboard Screen
@Composable
fun DashboardScreen(userId: String) {
    var tanks by remember { mutableStateOf(listOf<Tank>()) }
    
    // Simulate data
    LaunchedEffect(Unit) {
        tanks = listOf(
            Tank(
                id = "tank_1",
                name = "Main Tank",
                height = 200,
                waterLevelPercentage = 75,
                waterLevelCm = 150,
                status = TankStatus.NORMAL,
                batteryPercentage = 85,
                wifiSignal = 4,
                lastUpdate = java.util.Date(),
                isOnline = true
            ),
            Tank(
                id = "tank_2",
                name = "Backup Tank",
                height = 150,
                waterLevelPercentage = 45,
                waterLevelCm = 68,
                status = TankStatus.LOW,
                batteryPercentage = 60,
                wifiSignal = 3,
                lastUpdate = java.util.Date(),
                isOnline = true
            )
        )
    }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
            .padding(16.dp)
    ) {
        item {
            Text(
                "Your Tanks",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A),
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
        
        items(tanks.size) { index ->
            TankCard(tanks[index])
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun TankCard(tank: Tank) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(0.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Tank Header
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        tank.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1A1A)
                    )
                    Text(
                        "Height: ${tank.height} cm",
                        fontSize = 12.sp,
                        color = Color(0xFF999999)
                    )
                }
                
                StatusBadge(tank.status, tank.isOnline)
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Water Level Progress
            Text(
                "Water Level",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF666666)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            LinearProgressIndicator(
                progress = tank.waterLevelPercentage / 100f,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = when {
                    tank.waterLevelPercentage >= 90 -> Color(0xFFFF6B6B)
                    tank.waterLevelPercentage >= 70 -> Color(0xFF51CF66)
                    tank.waterLevelPercentage >= 30 -> Color(0xFFFFA500)
                    else -> Color(0xFFFF6B6B)
                }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${tank.waterLevelPercentage}%",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1A1A1A)
                )
                Text(
                    "${tank.waterLevelCm} cm",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1A1A1A)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Status Row
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatusItem("Battery", "${tank.batteryPercentage}%", Icons.Filled.BatteryCharging50)
                StatusItem("WiFi", signalLabel(tank.wifiSignal), Icons.Filled.SignalCellularAlt)
                StatusItem("Updated", "2m ago", Icons.Filled.Schedule)
            }
        }
    }
}

@Composable
fun StatusItem(label: String, value: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(0.32f)
    ) {
        Icon(
            icon,
            contentDescription = label,
            modifier = Modifier.size(20.dp),
            tint = Color(0xFF0066CC)
        )
        Column(modifier = Modifier.padding(start = 8.dp)) {
            Text(label, fontSize = 10.sp, color = Color(0xFF999999))
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A1A1A))
        }
    }
}

@Composable
fun StatusBadge(status: TankStatus, isOnline: Boolean) {
    val backgroundColor = when (status) {
        TankStatus.NORMAL -> Color(0xFFE8F5E9)
        TankStatus.LOW -> Color(0xFFFFEBEE)
        TankStatus.FULL -> Color(0xFFE3F2FD)
        TankStatus.OFFLINE -> Color(0xFFF5F5F5)
    }
    
    val textColor = when (status) {
        TankStatus.NORMAL -> Color(0xFF2E7D32)
        TankStatus.LOW -> Color(0xFFC62828)
        TankStatus.FULL -> Color(0xFF1565C0)
        TankStatus.OFFLINE -> Color(0xFF666666)
    }
    
    Surface(
        color = backgroundColor,
        shape = RoundedCornerShape(20.dp)
    ) {
        Text(
            if (isOnline) status.name else "OFFLINE",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = textColor,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

fun signalLabel(signal: Int): String {
    return when (signal) {
        in 4..5 -> "Excellent"
        in 3..3 -> "Good"
        in 2..2 -> "Fair"
        else -> "Poor"
    }
}

