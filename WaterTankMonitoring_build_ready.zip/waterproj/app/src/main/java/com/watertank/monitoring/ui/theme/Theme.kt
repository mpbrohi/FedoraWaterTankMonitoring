package com.watertank.monitoring.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF0066CC),
    secondary = Color(0xFF00A8FF),
    tertiary = Color(0xFF51CF66),
    background = Color(0xFFF5F7FA),
    surface = Color.White,
    error = Color(0xFFFF6B6B)
)

@Composable
fun WaterTankTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
