@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.watertank.monitoring.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.watertank.monitoring.data.Alert
import com.watertank.monitoring.data.AlertType
import com.watertank.monitoring.data.Tank
import com.watertank.monitoring.data.TankStatus
import java.text.SimpleDateFormat
import java.util.*

// Add Tank Screen
@Composable
fun AddTankScreen() {
    var tankName by remember { mutableStateOf("") }
    var tankHeight by remember { mutableStateOf("") }
    var deviceId by remember { mutableStateOf("") }
    var showQRScanner by remember { mutableStateOf(false) }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
            .padding(16.dp)
    ) {
        item {
            Text(
                "Add New Tank",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A),
                modifier = Modifier.padding(bottom = 24.dp)
            )
        }
        
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Tank Information",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1A1A)
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    OutlinedTextField(
                        value = tankName,
                        onValueChange = { tankName = it },
                        label = { Text("Tank Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Label, null) }
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    OutlinedTextField(
                        value = tankHeight,
                        onValueChange = { tankHeight = it },
                        label = { Text("Tank Height (cm)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Straighten, null) }
                    )
                }
            }
        }
        
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Device Configuration",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1A1A)
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    OutlinedTextField(
                        value = deviceId,
                        onValueChange = { deviceId = it },
                        label = { Text("Device ID") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Devices, null) },
                        trailingIcon = {
                            IconButton(onClick = { showQRScanner = true }) {
                                Icon(Icons.Filled.QrCode, "Scan QR", tint = Color(0xFF0066CC))
                            }
                        }
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Button(
                        onClick = { showQRScanner = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF0F4FF)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.QrCode, null, modifier = Modifier.padding(end = 8.dp))
                        Text("Scan QR Code", color = Color(0xFF0066CC))
                    }
                }
            }
        }
        
        item {
            Button(
                onClick = { /* Add tank */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0066CC)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Filled.Add, null, modifier = Modifier.padding(end = 8.dp))
                Text("Add Tank")
            }
        }
    }
}

// Alerts Screen
@Composable
fun AlertsScreen() {
    var alerts by remember { mutableStateOf(listOf<Alert>()) }
    var selectedFilter by remember { mutableStateOf("all") }
    
    LaunchedEffect(Unit) {
        alerts = listOf(
            Alert(
                id = "alert_1",
                tankId = "tank_1",
                type = AlertType.LOW_WATER,
                message = "Main Tank water level is low",
                timestamp = Date(),
                isRead = false
            ),
            Alert(
                id = "alert_2",
                tankId = "tank_2",
                type = AlertType.LOW_BATTERY,
                message = "Backup Tank sensor battery low",
                timestamp = Date(System.currentTimeMillis() - 3600000),
                isRead = true
            ),
            Alert(
                id = "alert_3",
                tankId = "tank_1",
                type = AlertType.DEVICE_OFFLINE,
                message = "Main Tank device offline",
                timestamp = Date(System.currentTimeMillis() - 7200000),
                isRead = true
            )
        )
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
    ) {
        // Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "Alerts & Notifications",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Filter Chips
            Row(modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = selectedFilter == "all",
                    onClick = { selectedFilter = "all" },
                    label = { Text("All") },
                    modifier = Modifier.padding(end = 8.dp)
                )
                FilterChip(
                    selected = selectedFilter == "unread",
                    onClick = { selectedFilter = "unread" },
                    label = { Text("Unread") },
                    modifier = Modifier.padding(end = 8.dp)
                )
                FilterChip(
                    selected = selectedFilter == "low_water",
                    onClick = { selectedFilter = "low_water" },
                    label = { Text("Low Water") }
                )
            }
        }
        
        // Alerts List
        LazyColumn(modifier = Modifier.padding(horizontal = 16.dp)) {
            items(alerts) { alert ->
                AlertCard(alert)
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun AlertCard(alert: Alert) {
    val backgroundColor = if (alert.isRead) Color.White else Color(0xFFF0F4FF)
    val alertColor = when (alert.type) {
        AlertType.LOW_WATER -> Color(0xFFFF6B6B)
        AlertType.TANK_FULL -> Color(0xFF51CF66)
        AlertType.DEVICE_OFFLINE -> Color(0xFF999999)
        AlertType.LOW_BATTERY -> Color(0xFFFFA500)
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(0.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = alertColor.copy(alpha = 0.1f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(48.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        when (alert.type) {
                            AlertType.LOW_WATER -> Icons.Filled.WaterDrop
                            AlertType.TANK_FULL -> Icons.Filled.CheckCircle
                            AlertType.DEVICE_OFFLINE -> Icons.Filled.SignalCellularOff
                            AlertType.LOW_BATTERY -> Icons.Filled.BatteryAlert
                        },
                        contentDescription = null,
                        tint = alertColor,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        alert.message,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1A1A),
                        modifier = Modifier.weight(1f)
                    )
                    
                    if (!alert.isRead) {
                        Surface(
                            color = Color(0xFF0066CC),
                            shape = RoundedCornerShape(50.dp),
                            modifier = Modifier.size(8.dp)
                        ) {}
                    }
                }
                
                Text(
                    formatDate(alert.timestamp),
                    fontSize = 12.sp,
                    color = Color(0xFF999999),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

// Settings Screen
@Composable
fun SettingsScreen() {
    var notificationsEnabled by remember { mutableStateOf(true) }
    var lowWaterThreshold by remember { mutableStateOf("30") }
    var autoUpdateEnabled by remember { mutableStateOf(true) }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
            .padding(16.dp)
    ) {
        item {
            Text(
                "Settings",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A),
                modifier = Modifier.padding(bottom = 24.dp)
            )
        }
        
        item {
            SectionHeader("Notifications")
        }
        
        item {
            SettingsCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Enable Notifications",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1A1A1A)
                        )
                        Text(
                            "Get alerts for tank events",
                            fontSize = 12.sp,
                            color = Color(0xFF999999)
                        )
                    }
                    
                    Switch(
                        checked = notificationsEnabled,
                        onCheckedChange = { notificationsEnabled = it }
                    )
                }
            }
        }
        
        item {
            SettingsCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Low Water Threshold",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1A1A1A)
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    OutlinedTextField(
                        value = lowWaterThreshold,
                        onValueChange = { lowWaterThreshold = it },
                        label = { Text("Percentage (%)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        singleLine = true
                    )
                }
            }
        }
        
        item {
            SectionHeader("General")
        }
        
        item {
            SettingsCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Auto Update Data",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1A1A1A)
                        )
                        Text(
                            "Refresh every 5 minutes",
                            fontSize = 12.sp,
                            color = Color(0xFF999999)
                        )
                    }
                    
                    Switch(
                        checked = autoUpdateEnabled,
                        onCheckedChange = { autoUpdateEnabled = it }
                    )
                }
            }
        }
        
        item {
            SettingsCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        "About App",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1A1A1A)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Version 1.0.0",
                        fontSize = 12.sp,
                        color = Color(0xFF999999)
                    )
                }
            }
        }
        
        item {
            Button(
                onClick = { /* Logout */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .padding(top = 24.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF6B6B)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Logout")
            }
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        title,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF0066CC),
        modifier = Modifier.padding(vertical = 16.dp)
    )
}

@Composable
fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        content()
    }
}

// Tank History Screen
@Composable
fun TankHistoryScreen(tankId: String) {
    var selectedPeriod by remember { mutableStateOf("24h") }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FA))
            .padding(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceEvenly
            ) {
                FilterChip(
                    selected = selectedPeriod == "24h",
                    onClick = { selectedPeriod = "24h" },
                    label = { Text("24 Hours") }
                )
                FilterChip(
                    selected = selectedPeriod == "7d",
                    onClick = { selectedPeriod = "7d" },
                    label = { Text("7 Days") }
                )
                FilterChip(
                    selected = selectedPeriod == "30d",
                    onClick = { selectedPeriod = "30d" },
                    label = { Text("30 Days") }
                )
            }
        }
    }
}

// Helper function
fun formatDate(date: Date): String {
    val now = Date()
    val diff = now.time - date.time
    val hours = diff / (1000 * 60 * 60)
    
    return when {
        hours == 0L -> "Just now"
        hours == 1L -> "1 hour ago"
        hours < 24 -> "$hours hours ago"
        else -> SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(date)
    }
}
