package com.watertank.monitoring.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Dao
import androidx.room.Query
import androidx.room.Insert
import androidx.room.Update
import androidx.room.Delete
import kotlinx.coroutines.flow.Flow

// Database
@Database(
    entities = [TankEntity::class, WaterLevelEntity::class, AlertEntity::class],
    version = 1
)
abstract class TankMonitoringDatabase : RoomDatabase() {
    abstract fun tankDao(): TankDao
    abstract fun waterLevelDao(): WaterLevelDao
    abstract fun alertDao(): AlertDao
    
    companion object {
        @Volatile
        private var instance: TankMonitoringDatabase? = null
        
        fun getInstance(context: Context): TankMonitoringDatabase {
            return instance ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    TankMonitoringDatabase::class.java,
                    "tank_monitoring_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                .also { instance = it }
            }
        }
    }
}

// DAOs
@Dao
interface TankDao {
    @Query("SELECT * FROM tanks WHERE userId = :userId AND isActive = 1")
    fun getUserTanks(userId: String): Flow<List<TankEntity>>
    
    @Query("SELECT * FROM tanks WHERE id = :tankId")
    fun getTankById(tankId: String): Flow<TankEntity?>
    
    @Insert
    suspend fun insertTank(tank: TankEntity)
    
    @Update
    suspend fun updateTank(tank: TankEntity)
    
    @Delete
    suspend fun deleteTank(tank: TankEntity)
}

@Dao
interface WaterLevelDao {
    @Query("SELECT * FROM water_levels WHERE tankId = :tankId ORDER BY timestamp DESC LIMIT 1")
    fun getLatestLevel(tankId: String): Flow<WaterLevelEntity?>
    
    @Query("""
        SELECT * FROM water_levels 
        WHERE tankId = :tankId AND timestamp >= :since
        ORDER BY timestamp DESC
    """)
    fun getLevelHistory(tankId: String, since: Long): Flow<List<WaterLevelEntity>>
    
    @Query("""
        SELECT * FROM water_levels 
        WHERE tankId = :tankId 
        ORDER BY timestamp DESC
        LIMIT :limit
    """)
    fun getRecentLevels(tankId: String, limit: Int): Flow<List<WaterLevelEntity>>
    
    @Insert
    suspend fun insertLevel(level: WaterLevelEntity)
    
    @Query("DELETE FROM water_levels WHERE timestamp < :beforeTime")
    suspend fun deleteOldRecords(beforeTime: Long)
}

@Dao
interface AlertDao {
    @Query("SELECT * FROM alerts WHERE tankId = :tankId ORDER BY timestamp DESC")
    fun getTankAlerts(tankId: String): Flow<List<AlertEntity>>
    
    @Query("SELECT * FROM alerts WHERE isRead = 0 ORDER BY timestamp DESC")
    fun getUnreadAlerts(): Flow<List<AlertEntity>>
    
    @Query("SELECT * FROM alerts ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentAlerts(limit: Int): Flow<List<AlertEntity>>
    
    @Insert
    suspend fun insertAlert(alert: AlertEntity)
    
    @Update
    suspend fun updateAlert(alert: AlertEntity)
    
    @Query("UPDATE alerts SET isRead = 1 WHERE id = :alertId")
    suspend fun markAsRead(alertId: String)
    
    @Query("DELETE FROM alerts WHERE timestamp < :beforeTime")
    suspend fun deleteOldAlerts(beforeTime: Long)
}

// Repository
class TankRepository(
    private val tankDao: TankDao,
    private val waterLevelDao: WaterLevelDao,
    private val alertDao: AlertDao
) {
    
    fun getUserTanks(userId: String) = tankDao.getUserTanks(userId)
    
    fun getTankById(tankId: String) = tankDao.getTankById(tankId)
    
    fun getLatestWaterLevel(tankId: String) = waterLevelDao.getLatestLevel(tankId)
    
    fun getWaterLevelHistory(tankId: String, hours: Int): Flow<List<WaterLevelEntity>> {
        val since = System.currentTimeMillis() - (hours * 60 * 60 * 1000L)
        return waterLevelDao.getLevelHistory(tankId, since)
    }
    
    fun getTankAlerts(tankId: String) = alertDao.getTankAlerts(tankId)
    
    fun getUnreadAlerts() = alertDao.getUnreadAlerts()
    
    suspend fun addTank(tank: TankEntity) = tankDao.insertTank(tank)
    
    suspend fun updateTank(tank: TankEntity) = tankDao.updateTank(tank)
    
    suspend fun deleteTank(tank: TankEntity) = tankDao.deleteTank(tank)
    
    suspend fun addWaterLevel(level: WaterLevelEntity) = waterLevelDao.insertLevel(level)
    
    suspend fun addAlert(alert: AlertEntity) = alertDao.insertAlert(alert)
    
    suspend fun markAlertAsRead(alertId: String) = alertDao.markAsRead(alertId)
    
    suspend fun cleanup() {
        val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
        waterLevelDao.deleteOldRecords(thirtyDaysAgo)
        alertDao.deleteOldAlerts(thirtyDaysAgo)
    }
}
