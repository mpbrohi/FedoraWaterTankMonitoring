package com.watertank.monitoring.di

import android.content.Context
import com.watertank.monitoring.data.TankMonitoringDatabase
import com.watertank.monitoring.data.TankRepository
import com.watertank.monitoring.network.ApiClient
import com.watertank.monitoring.network.ApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    
    @Provides
    @Singleton
    fun provideTankMonitoringDatabase(
        @ApplicationContext context: Context
    ): TankMonitoringDatabase {
        return TankMonitoringDatabase.getInstance(context)
    }
    
    @Provides
    @Singleton
    fun provideTankRepository(database: TankMonitoringDatabase): TankRepository {
        return TankRepository(
            tankDao = database.tankDao(),
            waterLevelDao = database.waterLevelDao(),
            alertDao = database.alertDao()
        )
    }
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    
    @Provides
    @Singleton
    fun provideApiClient(): ApiClient {
        return ApiClient(baseUrl = "https://api.watertank.com")
    }
    
    @Provides
    @Singleton
    fun provideApiService(apiClient: ApiClient): ApiService {
        return ApiService(apiClient)
    }
}
