package com.watertank.monitoring.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.watertank.monitoring.data.*
import com.watertank.monitoring.network.ApiService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ============================================
// Authentication ViewModel
// ============================================
@HiltViewModel
class AuthViewModel @Inject constructor(
    private val apiService: ApiService,
    private val repository: TankRepository
) : ViewModel() {
    
    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()
    
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()
    
    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val result = apiService.login(email, password)
                result.onSuccess { response ->
                    _currentUser.value = response.user
                    _authState.value = AuthState.Success(response.user)
                }.onFailure { error ->
                    _authState.value = AuthState.Error(error.message ?: "Login failed")
                }
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Unknown error")
            }
        }
    }
    
    fun register(email: String, password: String, name: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val result = apiService.register(email, password, name)
                result.onSuccess { response ->
                    _currentUser.value = response.user
                    _authState.value = AuthState.Success(response.user)
                }.onFailure { error ->
                    _authState.value = AuthState.Error(error.message ?: "Registration failed")
                }
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Unknown error")
            }
        }
    }
    
    fun logout() {
        _currentUser.value = null
        _authState.value = AuthState.Idle
        viewModelScope.launch {
            repository.cleanup()
        }
    }
}

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    data class Success(val user: User) : AuthState()
    data class Error(val message: String) : AuthState()
}

// ============================================
// Tank ViewModel
// ============================================
@HiltViewModel
class TankViewModel @Inject constructor(
    private val apiService: ApiService,
    private val repository: TankRepository
) : ViewModel() {
    
    private val _tanks = MutableStateFlow<List<Tank>>(emptyList())
    val tanks: StateFlow<List<Tank>> = _tanks.asStateFlow()
    
    private val _selectedTank = MutableStateFlow<Tank?>(null)
    val selectedTank: StateFlow<Tank?> = _selectedTank.asStateFlow()
    
    private val _waterLevelHistory = MutableStateFlow<List<WaterLevelReading>>(emptyList())
    val waterLevelHistory: StateFlow<List<WaterLevelReading>> = _waterLevelHistory.asStateFlow()
    
    private val _loadingState = MutableStateFlow<LoadingState>(LoadingState.Idle)
    val loadingState: StateFlow<LoadingState> = _loadingState.asStateFlow()
    
    fun loadTanks(userId: String) {
        viewModelScope.launch {
            _loadingState.value = LoadingState.Loading
            try {
                val result = apiService.getTanks()
                result.onSuccess { tankResponses ->
                    val tankList = tankResponses.map { response ->
                        Tank(
                            id = response.id,
                            name = response.name,
                            height = response.height,
                            waterLevelPercentage = response.currentLevel,
                            waterLevelCm = response.currentLevelCm,
                            status = when {
                                response.currentLevel == 0 -> TankStatus.OFFLINE
                                response.currentLevel >= 90 -> TankStatus.FULL
                                response.currentLevel <= 30 -> TankStatus.LOW
                                else -> TankStatus.NORMAL
                            },
                            batteryPercentage = response.battery,
                            wifiSignal = response.wifi,
                            lastUpdate = java.util.Date(response.lastUpdate),
                            isOnline = response.isOnline
                        )
                    }
                    _tanks.value = tankList
                    _loadingState.value = LoadingState.Success
                }.onFailure { error ->
                    _loadingState.value = LoadingState.Error(error.message ?: "Failed to load tanks")
                }
            } catch (e: Exception) {
                _loadingState.value = LoadingState.Error(e.message ?: "Unknown error")
            }
        }
    }
    
    fun selectTank(tankId: String) {
        _selectedTank.value = _tanks.value.find { it.id == tankId }
    }
    
    fun loadWaterLevelHistory(tankId: String, hours: Int = 24) {
        viewModelScope.launch {
            try {
                val result = apiService.getWaterLevelHistory(tankId, hours)
                result.onSuccess { readings ->
                    _waterLevelHistory.value = readings.sortedBy { it.timestamp }
                }.onFailure { error ->
                    // Handle error silently - keep existing data
                }
            } catch (e: Exception) {
                // Handle error silently
            }
        }
    }
    
    fun addTank(name: String, height: Int, deviceId: String) {
        viewModelScope.launch {
            _loadingState.value = LoadingState.Loading
            try {
                val request = AddTankRequest(name, height, deviceId)
                val result = apiService.addTank(request)
                result.onSuccess {
                    loadTanks("") // Reload tanks
                    _loadingState.value = LoadingState.Success
                }.onFailure { error ->
                    _loadingState.value = LoadingState.Error(error.message ?: "Failed to add tank")
                }
            } catch (e: Exception) {
                _loadingState.value = LoadingState.Error(e.message ?: "Unknown error")
            }
        }
    }
    
    fun deleteTank(tankId: String) {
        viewModelScope.launch {
            try {
                apiService.deleteTank(tankId)
                _tanks.value = _tanks.value.filter { it.id != tankId }
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
}

sealed class LoadingState {
    object Idle : LoadingState()
    object Loading : LoadingState()
    object Success : LoadingState()
    data class Error(val message: String) : LoadingState()
}

// ============================================
// Alert ViewModel
// ============================================
@HiltViewModel
class AlertViewModel @Inject constructor(
    private val apiService: ApiService,
    private val repository: TankRepository
) : ViewModel() {
    
    private val _alerts = MutableStateFlow<List<Alert>>(emptyList())
    val alerts: StateFlow<List<Alert>> = _alerts.asStateFlow()
    
    private val _unreadCount = MutableStateFlow(0)
    val unreadCount: StateFlow<Int> = _unreadCount.asStateFlow()
    
    private val _filteredAlerts = MutableStateFlow<List<Alert>>(emptyList())
    val filteredAlerts: StateFlow<List<Alert>> = _filteredAlerts.asStateFlow()
    
    fun loadAlerts() {
        viewModelScope.launch {
            try {
                val result = apiService.getAlerts()
                result.onSuccess { alertList ->
                    _alerts.value = alertList.sortedByDescending { it.timestamp }
                    _unreadCount.value = alertList.count { !it.isRead }
                    _filteredAlerts.value = alertList
                }
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
    
    fun filterAlerts(filter: AlertFilter) {
        val filtered = when (filter) {
            AlertFilter.ALL -> _alerts.value
            AlertFilter.UNREAD -> _alerts.value.filter { !it.isRead }
            AlertFilter.LOW_WATER -> _alerts.value.filter { it.type == AlertType.LOW_WATER }
            AlertFilter.FULL -> _alerts.value.filter { it.type == AlertType.TANK_FULL }
            AlertFilter.OFFLINE -> _alerts.value.filter { it.type == AlertType.DEVICE_OFFLINE }
            AlertFilter.LOW_BATTERY -> _alerts.value.filter { it.type == AlertType.LOW_BATTERY }
        }
        _filteredAlerts.value = filtered
    }
    
    fun markAsRead(alertId: String) {
        viewModelScope.launch {
            try {
                apiService.markAlertAsRead(alertId)
                val updated = _alerts.value.map { alert ->
                    if (alert.id == alertId) alert.copy(isRead = true) else alert
                }
                _alerts.value = updated
                _unreadCount.value = updated.count { !it.isRead }
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
    
    fun deleteAlert(alertId: String) {
        viewModelScope.launch {
            try {
                apiService.deleteAlert(alertId)
                _alerts.value = _alerts.value.filter { it.id != alertId }
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
    
    fun clearAllAlerts() {
        viewModelScope.launch {
            val alertIds = _alerts.value.map { it.id }
            alertIds.forEach { id ->
                try {
                    apiService.deleteAlert(id)
                } catch (e: Exception) {
                    // Continue with next alert
                }
            }
            _alerts.value = emptyList()
        }
    }
}

enum class AlertFilter {
    ALL, UNREAD, LOW_WATER, FULL, OFFLINE, LOW_BATTERY
}

// ============================================
// Settings ViewModel
// ============================================
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: TankRepository
) : ViewModel() {
    
    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()
    
    fun updateNotifications(enabled: Boolean) {
        _settings.value = _settings.value.copy(notificationsEnabled = enabled)
    }
    
    fun updateLowWaterThreshold(threshold: Int) {
        _settings.value = _settings.value.copy(lowWaterThreshold = threshold)
    }
    
    fun updateAutoUpdate(enabled: Boolean) {
        _settings.value = _settings.value.copy(autoUpdateEnabled = enabled)
    }
    
    fun updateUpdateInterval(minutes: Int) {
        _settings.value = _settings.value.copy(updateIntervalMinutes = minutes)
    }
    
    fun clearDatabase() {
        viewModelScope.launch {
            repository.cleanup()
        }
    }
}

data class AppSettings(
    val notificationsEnabled: Boolean = true,
    val lowWaterThreshold: Int = 30,
    val autoUpdateEnabled: Boolean = true,
    val updateIntervalMinutes: Int = 5,
    val theme: String = "light"
)
