package com.watertank.monitoring.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

// Database Entities
@Entity(tableName = "tanks")
data class TankEntity(
    @PrimaryKey val id: String = "",
    val userId: String = "",
    val name: String = "",
    val height: Int = 0, // in cm
    val deviceId: String = "",
    val lastUpdate: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
)

@Entity(tableName = "water_levels")
data class WaterLevelEntity(
    @PrimaryKey val id: String = "",
    val tankId: String = "",
    val levelPercentage: Int = 0,
    val levelCm: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val batteryPercentage: Int = 0,
    val wifiSignal: Int = 0,
    val isOnline: Boolean = true
)

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey val id: String = "",
    val tankId: String = "",
    val type: String = "", // LOW_WATER, TANK_FULL, DEVICE_OFFLINE, LOW_BATTERY
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

// UI Models
data class Tank(
    val id: String,
    val name: String,
    val height: Int,
    val waterLevelPercentage: Int,
    val waterLevelCm: Int,
    val status: TankStatus,
    val batteryPercentage: Int,
    val wifiSignal: Int,
    val lastUpdate: Date,
    val isOnline: Boolean
)

enum class TankStatus {
    NORMAL, LOW, FULL, OFFLINE
}

data class WaterLevelReading(
    val timestamp: Date,
    val percentage: Int,
    val cm: Int,
    val batteryPercentage: Int,
    val wifiSignal: Int
)

data class Alert(
    val id: String,
    val tankId: String,
    val type: AlertType,
    val message: String,
    val timestamp: Date,
    val isRead: Boolean
)

enum class AlertType {
    LOW_WATER, TANK_FULL, DEVICE_OFFLINE, LOW_BATTERY
}

data class User(
    val id: String,
    val email: String,
    val name: String,
    val createdAt: Date
)

// API Request/Response Models
data class LoginRequest(
    val email: String,
    val password: String
)

data class RegisterRequest(
    val email: String,
    val password: String,
    val name: String
)

data class AuthResponse(
    val token: String,
    val user: User
)

data class AddTankRequest(
    val name: String,
    val height: Int,
    val deviceId: String
)

data class TankResponse(
    val id: String,
    val name: String,
    val height: Int,
    val currentLevel: Int,
    val currentLevelCm: Int,
    val battery: Int,
    val wifi: Int,
    val isOnline: Boolean,
    val lastUpdate: Long
)
