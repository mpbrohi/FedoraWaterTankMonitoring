package com.watertank.monitoring

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WaterTankApp : Application()
