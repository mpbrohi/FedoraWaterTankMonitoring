# Water Tank Monitoring Android App - Complete Guide

## 📱 Project Overview

ایک مکمل **Water Tank Monitoring Application** جو Android smartphones پر کام کرتی ہے۔ یہ app IoT sensors سے data حاصل کرتا ہے اور صارف کو real-time updates فراہم کرتا ہے۔

### Key Features:
- ✅ User Authentication (Login/Register)
- ✅ Multi-tank management
- ✅ Real-time water level monitoring
- ✅ QR code device pairing
- ✅ Alert notifications system
- ✅ 24hr/7 days/30 days history
- ✅ Battery & WiFi status monitoring
- ✅ Offline support with local database
- ✅ Modern Material Design 3 UI

---

## 🛠️ Technology Stack

### Frontend
- **Kotlin** - Programming language
- **Jetpack Compose** - Modern UI toolkit
- **Material Design 3** - Design system
- **Navigation Compose** - App navigation
- **Hilt** - Dependency injection

### Backend/Local
- **Room Database** - Local data persistence
- **Coroutines** - Asynchronous programming
- **OkHttp** - HTTP client
- **GSON** - JSON serialization

### Additional Libraries
- **ML Kit** - QR code scanning
- **CameraX** - Camera integration
- **Lifecycle** - Lifecycle management

---

## 📂 Project Structure

```
app/
├── src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/watertank/monitoring/
│   │   ├── MainActivity.kt          # Main activity & navigation
│   │   ├── WaterTankApp.kt          # App initialization
│   │   ├── data/
│   │   │   ├── DataModels.kt        # Data classes & entities
│   │   │   ├── Database.kt          # Room database & DAOs
│   │   │   └── TankRepository.kt    # Repository pattern
│   │   ├── network/
│   │   │   ├── ApiClient.kt         # HTTP client
│   │   │   └── ApiService.kt        # API service layer
│   │   ├── ui/
│   │   │   ├── Screens.kt           # Compose screens
│   │   │   ├── Components.kt        # Reusable components
│   │   │   └── theme/
│   │   │       └── Theme.kt         # App theme
│   │   ├── viewmodel/
│   │   │   ├── TankViewModel.kt     # Tank management logic
│   │   │   ├── AuthViewModel.kt     # Auth logic
│   │   │   └── AlertViewModel.kt    # Alert management
│   │   └── services/
│   │       ├── DataSyncService.kt   # Background sync
│   │       └── NotificationService.kt
│   └── res/
│       ├── values/
│       │   ├── strings.xml
│       │   ├── colors.xml
│       │   └── themes.xml
│       └── drawable/
├── build.gradle                      # Project configuration
└── settings.gradle

```

---

## 🚀 Setup Instructions

### Prerequisites
- Android Studio (Latest version)
- Android SDK 26 or higher
- Kotlin 1.9+
- Gradle 8.0+

### Step 1: Create New Project
```bash
# Open Android Studio
# File → New → New Android Project
# Select "Empty Activity" template
# Configure:
#   - Name: Water Tank Monitor
#   - Package: com.watertank.monitoring
#   - Min SDK: API 26
#   - Target SDK: API 34
```

### Step 2: Update build.gradle

Replace your `build.gradle` file with the provided one:

```gradle
plugins {
    id 'com.android.application'
    id 'kotlin-android'
    id 'kotlin-kapt'
    id 'dagger.hilt.android.plugin'
}

dependencies {
    // Copy from provided build.gradle file
}
```

### Step 3: Add Project Files

Copy these Kotlin files to your project:
- `DataModels.kt` → `java/com/watertank/monitoring/data/`
- `Database.kt` → `java/com/watertank/monitoring/data/`
- `ApiClient.kt` → `java/com/watertank/monitoring/network/`
- `MainActivity.kt` → `java/com/watertank/monitoring/`
- `Screens.kt` → `java/com/watertank/monitoring/ui/`

### Step 4: Create Theme File

Create `Theme.kt` in `ui/theme/`:

```kotlin
package com.watertank.monitoring.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF0066CC),
    secondary = Color(0xFF00A8FF),
    tertiary = Color(0xFF51CF66),
    background = Color(0xFFF5F7FA),
    surface = Color.White,
    error = Color(0xFFFF6B6B)
)

@Composable
fun WaterTankTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
```

### Step 5: Create App Class

Create `WaterTankApp.kt`:

```kotlin
package com.watertank.monitoring

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WaterTankApp : Application()
```

### Step 6: Configure AndroidManifest.xml

Use the provided `AndroidManifest.xml` file.

### Step 7: Create ViewModels

Create `TankViewModel.kt`:

```kotlin
package com.watertank.monitoring.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.watertank.monitoring.data.TankRepository
import com.watertank.monitoring.network.ApiService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TankViewModel @Inject constructor(
    private val repository: TankRepository,
    private val apiService: ApiService
) : ViewModel() {
    
    private val _tanks = MutableStateFlow<List<Tank>>(emptyList())
    val tanks: StateFlow<List<Tank>> = _tanks
    
    fun loadTanks(userId: String) {
        viewModelScope.launch {
            repository.getUserTanks(userId).collect { tanks ->
                _tanks.value = tanks.map { entity ->
                    Tank(
                        id = entity.id,
                        name = entity.name,
                        height = entity.height,
                        // ... map other fields
                    )
                }
            }
        }
    }
}
```

### Step 8: Build & Run

```bash
# In Android Studio terminal or command line
./gradlew build

# Or run directly on emulator/device
./gradlew installDebug
```

---

## 📐 App Architecture

### MVVM Pattern
```
UI Layer (Compose) → ViewModel → Repository → Data Sources
                        ↓
                   Network/Database
```

### Data Flow
```
Screens (UI) 
    ↓
ViewModels (State Management)
    ↓
Repository (Data Access)
    ↓
Network API + Local Database
```

---

## 🎨 UI Screens

### 1. Login Screen
- Email/Password input
- Register link
- Error handling
- Loading state

### 2. Dashboard
- Tank cards with water level
- Status indicators
- Quick stats (Battery, WiFi)
- Navigation to detail screens

### 3. Add Tank
- Tank name input
- Height configuration
- Device ID field
- QR code scanner button

### 4. Tank History
- Selectable time periods (24h, 7d, 30d)
- Water level graph
- Data points table

### 5. Alerts
- Alert list with filtering
- Alert type indicators
- Read/Unread status
- Timestamp display

### 6. Settings
- Notification toggle
- Low water threshold
- Auto-update interval
- About & Logout

---

## 🔌 API Integration

### Backend Requirements

Your backend should provide these endpoints:

#### Authentication
```
POST /auth/login
POST /auth/register
```

#### Tanks
```
GET /tanks                 # List all tanks
GET /tanks/:id            # Get specific tank
POST /tanks               # Add new tank
PUT /tanks/:id            # Update tank
DELETE /tanks/:id         # Delete tank
```

#### Water Levels
```
GET /tanks/:id/history    # Get water level history
```

#### Alerts
```
GET /alerts               # Get all alerts
PUT /alerts/:id/read      # Mark as read
DELETE /alerts/:id        # Delete alert
```

### Example API Response

```json
{
  "id": "tank_1",
  "name": "Main Tank",
  "height": 200,
  "currentLevel": 150,
  "currentLevelCm": 150,
  "battery": 85,
  "wifi": 4,
  "isOnline": true,
  "lastUpdate": 1694123456000
}
```

---

## 🔐 Security Best Practices

### 1. Authentication
```kotlin
// Store token securely using Android Keystore
val keyStore = KeyStore.getInstance("AndroidKeyStore")
keyStore.load(null)

// Or use EncryptedSharedPreferences
val masterKey = MasterKey.Builder(context)
    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
    .build()

val encryptedSharedPreferences = EncryptedSharedPreferences.create(
    context,
    "secret_shared_prefs",
    masterKey,
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)
```

### 2. Network Security
```xml
<!-- res/xml/network_security_config.xml -->
<network-security-config>
    <domain-config cleartextTrafficPermitted="false">
        <domain includeSubdomains="true">api.watertank.com</domain>
    </domain-config>
</network-security-config>
```

### 3. HTTPS Only
- Always use HTTPS for API calls
- Implement certificate pinning for sensitive data

---

## 📊 Database Schema

### Tanks Table
```sql
CREATE TABLE tanks (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL,
    name TEXT NOT NULL,
    height INTEGER NOT NULL,
    deviceId TEXT NOT NULL,
    lastUpdate INTEGER NOT NULL,
    isActive INTEGER NOT NULL
);
```

### Water Levels Table
```sql
CREATE TABLE water_levels (
    id TEXT PRIMARY KEY,
    tankId TEXT NOT NULL,
    levelPercentage INTEGER NOT NULL,
    levelCm INTEGER NOT NULL,
    timestamp INTEGER NOT NULL,
    batteryPercentage INTEGER NOT NULL,
    wifiSignal INTEGER NOT NULL,
    isOnline INTEGER NOT NULL
);
```

### Alerts Table
```sql
CREATE TABLE alerts (
    id TEXT PRIMARY KEY,
    tankId TEXT NOT NULL,
    type TEXT NOT NULL,
    message TEXT NOT NULL,
    timestamp INTEGER NOT NULL,
    isRead INTEGER NOT NULL
);
```

---

## 🔔 Notifications

### Setup Notification Channel

```kotlin
private fun createNotificationChannel() {
    val channel = NotificationChannel(
        "tank_alerts",
        "Tank Alerts",
        NotificationManager.IMPORTANCE_HIGH
    ).apply {
        description = "Notifications for water tank events"
        enableVibration(true)
        setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
            AudioAttributes.Builder().build())
    }
    
    val notificationManager = context.getSystemService(NotificationManager::class.java)
    notificationManager.createNotificationChannel(channel)
}
```

### Send Notification

```kotlin
fun sendNotification(title: String, message: String) {
    val notification = NotificationCompat.Builder(context, "tank_alerts")
        .setContentTitle(title)
        .setContentText(message)
        .setSmallIcon(R.drawable.ic_notification)
        .setAutoCancel(true)
        .build()
    
    NotificationManagerCompat.from(context).notify(System.currentTimeMillis().toInt(), notification)
}
```

---

## 🧪 Testing

### Unit Tests

```kotlin
// TankRepositoryTest.kt
@RunWith(RobolectricTestRunner::class)
class TankRepositoryTest {
    
    @Test
    fun testAddTank() {
        val tank = TankEntity(id = "test", name = "Test Tank")
        runBlockingTest {
            repository.addTank(tank)
            // Assert tank was added
        }
    }
}
```

### UI Tests

```kotlin
@LargeTest
@RunWith(AndroidJUnit4::class)
class LoginScreenTest {
    
    @get:Rule
    val composeTestRule = createComposeRule()
    
    @Test
    fun testLoginButton() {
        composeTestRule.setContent { LoginScreen() }
        composeTestRule.onNodeWithText("Login").performClick()
    }
}
```

---

## 📈 Performance Optimization

### 1. Database Cleanup
```kotlin
// Delete old records periodically
val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
database.waterLevelDao().deleteOldRecords(thirtyDaysAgo)
```

### 2. Lazy Loading
```kotlin
LazyColumn {
    items(tanks) { tank ->
        TankCard(tank)
    }
}
```

### 3. Image Caching
- Use Coil or Glide for image loading
- Implement LRU cache for network requests

---

## 🐛 Troubleshooting

### Build Issues
```
Error: Hilt dependency not found
Solution: Add google() repository in settings.gradle
```

### Runtime Crashes
```
Error: java.lang.ClassNotFoundException: DatabaseClass
Solution: Ensure Room entities are properly annotated
```

### Network Errors
```
Error: SSL certificate error
Solution: Configure proper network security config
```

---

## 📱 Testing on Device

### Via USB
```bash
# Enable USB debugging on device
# Run:
adb devices  # List connected devices
./gradlew installDebug  # Install app
```

### Via Emulator
```bash
# Create emulator with at least API 26
# Run emulator from Android Studio
./gradlew installDebug
```

---

## 🚀 Deployment

### Release Build
```bash
# Create signed APK
./gradlew assembleRelease

# Or AAB for Play Store
./gradlew bundleRelease
```

### Configure Signing
```gradle
signingConfigs {
    release {
        storeFile file("/path/to/keystore.jks")
        storePassword "password"
        keyAlias "alias"
        keyPassword "keyPassword"
    }
}
```

---

## 📞 Support

For issues or questions:
- Check logcat output: `./gradlew logcat`
- Review error messages carefully
- Consult Android documentation
- Test on real device if possible

---

## 📄 License

This project is open source and available under MIT License.

**Happy Coding! 🎉**
