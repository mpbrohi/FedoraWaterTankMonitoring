package com.watertank.monitoring.network

import com.google.gson.Gson
import com.watertank.monitoring.data.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class ApiClient(private val baseUrl: String = "https://api.watertank.com") {
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    private val gson = Gson()
    private var authToken: String? = null
    
    // Authentication APIs
    suspend fun login(email: String, password: String): Result<AuthResponse> {
        return try {
            val request = LoginRequest(email, password)
            val response = post("$baseUrl/auth/login", request)
            val authResponse = gson.fromJson(response, AuthResponse::class.java)
            authToken = authResponse.token
            Result.success(authResponse)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun register(email: String, password: String, name: String): Result<AuthResponse> {
        return try {
            val request = RegisterRequest(email, password, name)
            val response = post("$baseUrl/auth/register", request)
            val authResponse = gson.fromJson(response, AuthResponse::class.java)
            authToken = authResponse.token
            Result.success(authResponse)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Tank APIs
    suspend fun getTanks(): Result<List<TankResponse>> {
        return try {
            val response = get("$baseUrl/tanks")
            val tanks = gson.fromJson(
                response,
                Array<TankResponse>::class.java
            ).toList()
            Result.success(tanks)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun getTank(tankId: String): Result<TankResponse> {
        return try {
            val response = get("$baseUrl/tanks/$tankId")
            val tank = gson.fromJson(response, TankResponse::class.java)
            Result.success(tank)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun addTank(request: AddTankRequest): Result<TankResponse> {
        return try {
            val response = post("$baseUrl/tanks", request)
            val tank = gson.fromJson(response, TankResponse::class.java)
            Result.success(tank)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun updateTank(tankId: String, request: AddTankRequest): Result<TankResponse> {
        return try {
            val response = put("$baseUrl/tanks/$tankId", request)
            val tank = gson.fromJson(response, TankResponse::class.java)
            Result.success(tank)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun deleteTank(tankId: String): Result<Unit> {
        return try {
            delete("$baseUrl/tanks/$tankId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Water Level APIs
    suspend fun getWaterLevelHistory(
        tankId: String,
        hours: Int
    ): Result<List<WaterLevelReading>> {
        return try {
            val response = get("$baseUrl/tanks/$tankId/history?hours=$hours")
            val readings = gson.fromJson(
                response,
                Array<WaterLevelReading>::class.java
            ).toList()
            Result.success(readings)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Alert APIs
    suspend fun getAlerts(): Result<List<Alert>> {
        return try {
            val response = get("$baseUrl/alerts")
            val alerts = gson.fromJson(
                response,
                Array<Alert>::class.java
            ).toList()
            Result.success(alerts)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun markAlertAsRead(alertId: String): Result<Unit> {
        return try {
            put("$baseUrl/alerts/$alertId/read", Any())
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun deleteAlert(alertId: String): Result<Unit> {
        return try {
            delete("$baseUrl/alerts/$alertId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // HTTP Methods
    private suspend fun get(url: String): String {
        val request = Request.Builder()
            .url(url)
            .apply {
                authToken?.let { addHeader("Authorization", "Bearer $it") }
            }
            .build()
        
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("HTTP Error: ${response.code}")
            }
            response.body?.string() ?: ""
        }
    }
    
    private suspend fun post(url: String, body: Any): String {
        val jsonBody = gson.toJson(body)
        val request = Request.Builder()
            .url(url)
            .post(
                okhttp3.RequestBody.create(
                    "application/json".toMediaType(),
                    jsonBody
                )
            )
            .apply {
                authToken?.let { addHeader("Authorization", "Bearer $it") }
            }
            .build()
        
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("HTTP Error: ${response.code}")
            }
            response.body?.string() ?: ""
        }
    }
    
    private suspend fun put(url: String, body: Any): String {
        val jsonBody = gson.toJson(body)
        val request = Request.Builder()
            .url(url)
            .put(
                okhttp3.RequestBody.create(
                    "application/json".toMediaType(),
                    jsonBody
                )
            )
            .apply {
                authToken?.let { addHeader("Authorization", "Bearer $it") }
            }
            .build()
        
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("HTTP Error: ${response.code}")
            }
            response.body?.string() ?: ""
        }
    }
    
    private suspend fun delete(url: String): String {
        val request = Request.Builder()
            .url(url)
            .delete()
            .apply {
                authToken?.let { addHeader("Authorization", "Bearer $it") }
            }
            .build()
        
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("HTTP Error: ${response.code}")
            }
            response.body?.string() ?: ""
        }
    }
    
    fun setAuthToken(token: String) {
        this.authToken = token
    }
    
    fun clearAuthToken() {
        this.authToken = null
    }
}

// API Service with Coroutine Support
class ApiService(private val client: ApiClient) {
    
    // Authentication
    suspend fun login(email: String, password: String) = 
        client.login(email, password)
    
    suspend fun register(email: String, password: String, name: String) = 
        client.register(email, password, name)
    
    // Tanks
    suspend fun getTanks() = client.getTanks()
    suspend fun getTank(tankId: String) = client.getTank(tankId)
    suspend fun addTank(request: AddTankRequest) = client.addTank(request)
    suspend fun updateTank(tankId: String, request: AddTankRequest) = 
        client.updateTank(tankId, request)
    suspend fun deleteTank(tankId: String) = client.deleteTank(tankId)
    
    // Water Levels
    suspend fun getWaterLevelHistory(tankId: String, hours: Int) = 
        client.getWaterLevelHistory(tankId, hours)
    
    // Alerts
    suspend fun getAlerts() = client.getAlerts()
    suspend fun markAlertAsRead(alertId: String) = client.markAlertAsRead(alertId)
    suspend fun deleteAlert(alertId: String) = client.deleteAlert(alertId)
}
