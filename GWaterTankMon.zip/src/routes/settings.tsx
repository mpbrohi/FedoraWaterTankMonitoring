import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardDesc, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useTankStore } from "@/lib/store";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const settings = useTankStore((s) => s.settings);
  const updateSettings = useTankStore((s) => s.updateSettings);

  return (
    <AppShell>
      <h1 className="text-2xl font-medium tracking-tight">Settings</h1>
      <p className="mt-1 max-w-xl text-sm leading-normal text-muted">
        Polling, alerts, and how this dashboard talks to your ultrasonic node.
      </p>

      <Card className="mt-5">
        <CardHeader>
          <CardTitle>Polling</CardTitle>
          <CardDesc>How often demo ticks or live ESP fetches run.</CardDesc>
        </CardHeader>
        <Field label="Interval (seconds)" hint="2–60. Live hardware can use 5–15 s to keep the sensor cool.">
          <Input
            type="number"
            min={2}
            max={60}
            value={settings.pollSeconds}
            onChange={(e) =>
              updateSettings({ pollSeconds: Math.min(60, Math.max(2, Number(e.target.value) || 4)) })
            }
          />
        </Field>
      </Card>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Notifications</CardTitle>
          <CardDesc>Browser alerts when water goes low, the tank fills, or the ESP drops.</CardDesc>
        </CardHeader>
        <div className="flex items-center justify-between gap-3">
          <p className="min-w-0 text-sm">Enable desktop notifications</p>
          <Switch
            checked={settings.notifications}
            onCheckedChange={(on) => {
              updateSettings({ notifications: on });
              if (on && typeof Notification !== "undefined") {
                void Notification.requestPermission().then((p) => {
                  toast(p === "granted" ? "Notifications on" : "Permission denied");
                });
              }
            }}
          />
        </div>
        <div className="mt-4">
          <Field label="High temperature alert (°C)">
            <Input
              type="number"
              min={20}
              max={80}
              value={settings.tempWarnC}
              onChange={(e) =>
                updateSettings({ tempWarnC: Number(e.target.value) || 40 })
              }
            />
          </Field>
        </div>
      </Card>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>How the math works</CardTitle>
        </CardHeader>
        <ol className="list-decimal space-y-2 pl-5 text-sm leading-normal text-muted">
          <li>Mount HC-SR04 on the lid, facing the water.</li>
          <li>ESP measures empty distance in cm.</li>
          <li>
            Water height = tank height − distance − sensor offset.
          </li>
          <li>Percent = water height ÷ usable height. Litres scale from capacity.</li>
        </ol>
        <p className="mt-4 text-sm leading-normal text-muted">
          History is stored in this browser. AquaLevel 1.0 — ESP32 + ultrasonic.
        </p>
        <Button
          className="mt-4"
          variant="outline"
          onClick={() => {
            localStorage.removeItem("aqualevel-v2");
            window.location.reload();
          }}
        >
          Reset demo data
        </Button>
      </Card>
    </AppShell>
  );
}
