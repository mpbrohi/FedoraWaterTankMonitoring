import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Beaker, Gauge, Ruler, Thermometer, Waves, Wifi } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { HistoryTable } from "@/components/history-table";
import { LevelChart } from "@/components/level-chart";
import { StatTile } from "@/components/stat-tile";
import { StatusPill } from "@/components/status-pill";
import { TankVisual } from "@/components/tank-visual";
import { TempGauge } from "@/components/temp-gauge";
import { Badge } from "@/components/ui/badge";
import { Card, CardDesc, CardHeader, CardTitle } from "@/components/ui/card";
import { rangeMs, selectedTank, tankStatus, useTankStore } from "@/lib/store";
import type { HistoryRange } from "@/lib/types";
import { cn, formatLiters, relativeTime, rssiLabel } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const RANGES: HistoryRange[] = ["24h", "7d", "30d"];

function Home() {
  const hydrated = useTankStore((s) => s.hydrated);
  const tanks = useTankStore((s) => s.tanks);
  const selectedId = useTankStore((s) => s.selectedId);
  const selectTank = useTankStore((s) => s.selectTank);
  const latest = useTankStore((s) => s.latest);
  const history = useTankStore((s) => s.history);
  const pollError = useTankStore((s) => s.pollError);
  const [range, setRange] = useState<HistoryRange>("24h");

  const tank = selectedTank({ tanks, selectedId });
  const reading = tank ? latest[tank.id] : undefined;
  const series = tank ? (history[tank.id] ?? []) : [];
  const status = tank ? tankStatus(tank, reading) : "offline";
  const windowed = series.filter((r) => r.ts >= Date.now() - rangeMs(range));
  const firstL = windowed[0]?.liters ?? 0;
  const lastL = windowed[windowed.length - 1]?.liters ?? 0;
  const used = windowed.length >= 2 ? Math.max(0, firstL - lastL) : 0;

  if (!hydrated || !tank) {
    return (
      <AppShell>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="h-80 animate-pulse rounded-2xl bg-card" />
          <div className="h-80 animate-pulse rounded-2xl bg-card" />
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="mb-6 flex min-w-0 flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase tracking-wide text-muted">Live monitor</p>
          <h1 className="mt-1 text-2xl font-medium tracking-tight sm:text-3xl">{tank.name}</h1>
          <p className="mt-1 max-w-xl text-sm leading-normal text-muted">
            HC-SR04 measures empty space from the lid. Level = tank height − distance − sensor offset.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <StatusPill status={status} />
          <Badge tone={tank.mode === "live" ? "accent" : "neutral"}>
            <span
              className={cn(
                "mr-1.5 inline-block size-1.5 rounded-full bg-current",
                tank.mode === "demo" || reading?.online ? "live-dot" : "",
              )}
            />
            {tank.mode === "demo" ? "Demo sensor" : reading?.online ? "ESP live" : "ESP down"}
          </Badge>
        </div>
      </div>

      {tanks.length > 1 ? (
        <div className="mb-6 flex min-w-0 gap-2 overflow-x-auto pb-1">
          {tanks.map((t) => {
            const r = latest[t.id];
            const active = t.id === tank.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => selectTank(t.id)}
                className={cn(
                  "min-w-40 shrink-0 rounded-xl px-4 py-3 text-left shadow-[var(--shadow-border)] transition-colors duration-150",
                  active ? "bg-card-2" : "bg-card hover:bg-card-2",
                )}
              >
                <p className="truncate text-sm font-medium">{t.name}</p>
                <p className="mt-1 font-mono text-lg tabular-nums">
                  {r?.percent ?? "—"}
                  <span className="text-xs text-muted"> %</span>
                </p>
              </button>
            );
          })}
        </div>
      ) : null}

      {pollError[tank.id] ? (
        <p className="mb-4 rounded-xl bg-danger/10 px-4 py-3 text-sm leading-normal text-danger">
          {pollError[tank.id]}. The app keeps the last reading. Check ESP IP, CORS, and that the
          sketch serves GET /status.
        </p>
      ) : null}

      <div className="grid min-w-0 gap-4 lg:grid-cols-2">
        <Card className="flex flex-col items-center p-4 sm:p-6">
          <TankVisual
            percent={reading?.percent ?? 0}
            levelCm={reading?.levelCm ?? 0}
            heightCm={tank.heightCm}
            status={status}
          />
          <p className="mt-2 max-w-xs text-center text-xs leading-normal text-muted">
            Sight glass on the right is the level indicator. Waves follow live fill.
          </p>
        </Card>

        <div className="flex min-w-0 flex-col gap-4">
          <Card>
            <TempGauge tempC={reading?.tempC ?? null} humidity={reading?.humidity ?? null} />
          </Card>
          <div className="grid grid-cols-2 gap-3">
            <StatTile
              icon={Beaker}
              label="Volume"
              value={formatLiters(reading?.liters ?? 0)}
              hint={`of ${formatLiters(tank.capacityL)} capacity`}
            />
            <StatTile
              icon={Ruler}
              label="Empty distance"
              value={`${(reading?.distanceCm ?? 0).toFixed(1)} cm`}
              hint="Ultrasonic echo to water"
            />
            <StatTile
              icon={Waves}
              label="Water column"
              value={`${(reading?.levelCm ?? 0).toFixed(1)} cm`}
              hint={`Offset ${tank.sensorOffsetCm} cm`}
            />
            <StatTile
              icon={Wifi}
              label="Wi-Fi"
              value={rssiLabel(reading?.rssi ?? null)}
              hint={reading?.rssi != null ? `${reading.rssi} dBm` : "No RSSI yet"}
            />
            <StatTile
              icon={Gauge}
              label="Updated"
              value={reading ? relativeTime(reading.ts) : "—"}
              hint={tank.deviceId}
            />
            <StatTile
              icon={Thermometer}
              label="Humidity"
              value={reading?.humidity == null ? "—" : `${reading.humidity.toFixed(0)}%`}
              hint="From DHT on ESP"
            />
          </div>
        </div>
      </div>

      <Card className="mt-4">
        <CardHeader className="mb-2 flex-row flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <CardTitle>Level & temperature</CardTitle>
            <CardDesc>Teal fill is water level. Amber line is temperature from the ESP.</CardDesc>
          </div>
          <div className="flex rounded-full bg-card-2 p-1 shadow-[var(--shadow-border)]">
            {RANGES.map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRange(r)}
                className={cn(
                  "h-9 min-w-14 rounded-full px-3 text-xs font-medium",
                  range === r ? "bg-primary text-primary-foreground" : "text-muted",
                )}
              >
                {r}
              </button>
            ))}
          </div>
        </CardHeader>
        <LevelChart history={series} range={range} />
        <p className="mt-2 text-xs text-muted">
          {range} change {used > 0 ? `≈ ${formatLiters(used)} used` : "is a net fill or steady"}.
        </p>
      </Card>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Recent readings</CardTitle>
          <CardDesc>Stored on this device. Live polls append here automatically.</CardDesc>
        </CardHeader>
        <HistoryTable rows={series} />
      </Card>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {tanks.map((t) => {
          const r = latest[t.id];
          const st = tankStatus(t, r);
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => selectTank(t.id)}
              className="rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)]"
            >
              <div className="flex items-start justify-between gap-2">
                <p className="min-w-0 truncate font-medium">{t.name}</p>
                <StatusPill status={st} />
              </div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-card-2">
                <div
                  className={cn(
                    "h-full rounded-full transition-[width] duration-700",
                    st === "low" ? "bg-danger" : st === "full" ? "bg-accent" : "bg-water",
                  )}
                  style={{ width: `${r?.percent ?? 0}%` }}
                />
              </div>
              <p className="mt-2 font-mono text-sm tabular-nums text-muted">
                {r?.percent ?? 0}% · {formatLiters(r?.liters ?? 0)}
                {r?.tempC != null ? ` · ${r.tempC.toFixed(1)}°C` : ""}
              </p>
            </button>
          );
        })}
      </div>
    </AppShell>
  );
}
