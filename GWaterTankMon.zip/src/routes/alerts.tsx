import { createFileRoute } from "@tanstack/react-router";
import {
  AlertTriangle,
  BatteryWarning,
  CheckCircle2,
  RadioTower,
  Thermometer,
  Waves,
} from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import type { AlertType } from "@/lib/types";
import { useTankStore } from "@/lib/store";
import { cn, relativeTime } from "@/lib/utils";
import { useState } from "react";

export const Route = createFileRoute("/alerts")({ component: AlertsPage });

const ICONS: Record<AlertType, typeof Waves> = {
  low_water: Waves,
  tank_full: CheckCircle2,
  device_offline: RadioTower,
  sensor_fault: AlertTriangle,
  high_temp: Thermometer,
};

const TONE: Record<AlertType, string> = {
  low_water: "text-danger",
  tank_full: "text-ok",
  device_offline: "text-muted",
  sensor_fault: "text-warn",
  high_temp: "text-warn",
};

function AlertsPage() {
  const alerts = useTankStore((s) => s.alerts);
  const tanks = useTankStore((s) => s.tanks);
  const markAlertRead = useTankStore((s) => s.markAlertRead);
  const markAllRead = useTankStore((s) => s.markAllRead);
  const clearAlerts = useTankStore((s) => s.clearAlerts);
  const [filter, setFilter] = useState<"all" | "unread" | AlertType>("all");

  const filtered = alerts.filter((a) => {
    if (filter === "all") return true;
    if (filter === "unread") return !a.read;
    return a.type === filter;
  });

  const chips: { id: typeof filter; label: string }[] = [
    { id: "all", label: "All" },
    { id: "unread", label: "Unread" },
    { id: "low_water", label: "Low water" },
    { id: "tank_full", label: "Full" },
    { id: "device_offline", label: "Offline" },
  ];

  return (
    <AppShell>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-2xl font-medium tracking-tight">Alerts</h1>
          <p className="mt-1 max-w-xl text-sm leading-normal text-muted">
            Raised when level crosses your thresholds, the ESP goes quiet, or temperature spikes.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" size="sm" onClick={markAllRead}>
            Mark all read
          </Button>
          <Button variant="outline" size="sm" onClick={clearAlerts}>
            Clear
          </Button>
        </div>
      </div>

      <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
        {chips.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setFilter(c.id)}
            className={cn(
              "h-9 shrink-0 rounded-full px-3 text-xs font-medium shadow-[var(--shadow-border)]",
              filter === c.id ? "bg-primary text-primary-foreground" : "bg-card text-muted",
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <Card>
          <p className="text-sm text-muted">No alerts in this filter.</p>
        </Card>
      ) : (
        <ul className="flex flex-col gap-3">
          {filtered.map((a) => {
            const Icon = ICONS[a.type] ?? BatteryWarning;
            const tank = tanks.find((t) => t.id === a.tankId);
            return (
              <li key={a.id}>
                <button
                  type="button"
                  onClick={() => markAlertRead(a.id)}
                  className={cn(
                    "flex w-full min-w-0 items-start gap-3 rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)]",
                    !a.read && "ring-1 ring-accent/40",
                  )}
                >
                  <span className={cn("mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-md bg-card-2", TONE[a.type])}>
                    <Icon className="size-5" strokeWidth={1.75} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-start gap-2">
                      <span className="min-w-0 flex-1 text-sm font-medium leading-snug">
                        {a.message}
                      </span>
                      {!a.read ? <span className="mt-1 size-2 shrink-0 rounded-full bg-accent" /> : null}
                    </span>
                    <span className="mt-1 block text-xs text-muted">
                      {tank?.name ?? "Tank"} · {relativeTime(a.ts)}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </AppShell>
  );
}
