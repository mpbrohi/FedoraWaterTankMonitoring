import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardDesc, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/label";
import { Input, Textarea } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { ESP32_SKETCH, statusUrl } from "@/lib/esp";
import { selectedTank, useTankStore } from "@/lib/store";
import type { Tank } from "@/lib/types";
import { uid } from "@/lib/utils";

export const Route = createFileRoute("/device")({ component: DevicePage });

function DevicePage() {
  const tanks = useTankStore((s) => s.tanks);
  const selectedId = useTankStore((s) => s.selectedId);
  const selectTank = useTankStore((s) => s.selectTank);
  const upsertTank = useTankStore((s) => s.upsertTank);
  const removeTank = useTankStore((s) => s.removeTank);
  const applyManualJson = useTankStore((s) => s.applyManualJson);
  const pollLive = useTankStore((s) => s.pollLive);
  const tank = selectedTank({ tanks, selectedId });
  const [jsonText, setJsonText] = useState(
    '{\n  "distance_cm": 42.0,\n  "temperature_c": 28.4,\n  "humidity": 61,\n  "rssi": -52\n}',
  );

  if (!tank) {
    return (
      <AppShell>
        <p className="text-sm text-muted">Add a tank to configure the ESP.</p>
      </AppShell>
    );
  }

  const save = (patch: Partial<Tank>) => upsertTank({ ...tank, ...patch });

  return (
    <AppShell>
      <h1 className="text-2xl font-medium tracking-tight">Device</h1>
      <p className="mt-1 max-w-2xl text-sm leading-normal text-muted">
        Pair an ESP32 (or ESP8266) with an HC-SR04 looking down from the lid. The board serves
        JSON at <span className="font-mono text-foreground">/status</span>. Demo mode runs here
        so you can use the dashboard before the hardware is online.
      </p>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
        {tanks.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => selectTank(t.id)}
            className={
              t.id === tank.id
                ? "h-10 shrink-0 rounded-full bg-primary px-4 text-sm text-primary-foreground"
                : "h-10 shrink-0 rounded-full bg-card px-4 text-sm text-muted shadow-[var(--shadow-border)]"
            }
          >
            {t.name}
          </button>
        ))}
      </div>

      <div className="mt-4 grid min-w-0 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Tank & sensor</CardTitle>
            <CardDesc>Heights in centimetres. Offset is the gap from lid to the ultrasonic face.</CardDesc>
          </CardHeader>
          <div className="grid gap-4">
            <Field label="Name">
              <Input value={tank.name} onChange={(e) => save({ name: e.target.value })} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Height (cm)">
                <Input
                  type="number"
                  min={20}
                  value={tank.heightCm}
                  onChange={(e) => save({ heightCm: Number(e.target.value) || tank.heightCm })}
                />
              </Field>
              <Field label="Capacity (L)">
                <Input
                  type="number"
                  min={20}
                  value={tank.capacityL}
                  onChange={(e) => save({ capacityL: Number(e.target.value) || tank.capacityL })}
                />
              </Field>
              <Field label="Sensor offset (cm)">
                <Input
                  type="number"
                  min={0}
                  value={tank.sensorOffsetCm}
                  onChange={(e) =>
                    save({ sensorOffsetCm: Number(e.target.value) || 0 })
                  }
                />
              </Field>
              <Field label="Device ID">
                <Input value={tank.deviceId} onChange={(e) => save({ deviceId: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Low alert %">
                <Input
                  type="number"
                  min={1}
                  max={80}
                  value={tank.lowThreshold}
                  onChange={(e) => save({ lowThreshold: Number(e.target.value) || 25 })}
                />
              </Field>
              <Field label="Full alert %">
                <Input
                  type="number"
                  min={50}
                  max={100}
                  value={tank.fullThreshold}
                  onChange={(e) => save({ fullThreshold: Number(e.target.value) || 95 })}
                />
              </Field>
            </div>
          </div>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>ESP connection</CardTitle>
            <CardDesc>
              Live mode fetches {statusUrl(tank.espHost)}. Browsers block mixed HTTP from HTTPS
              pages — use demo here, live on the same LAN, or paste JSON below.
            </CardDesc>
          </CardHeader>
          <div className="flex items-center justify-between gap-3 rounded-xl bg-card-2 px-4 py-3">
            <div className="min-w-0">
              <p className="text-sm font-medium">Live ESP polling</p>
              <p className="text-xs leading-normal text-muted">Off = animated demo sensor</p>
            </div>
            <Switch
              checked={tank.mode === "live"}
              onCheckedChange={(on) => save({ mode: on ? "live" : "demo" })}
            />
          </div>
          <div className="mt-4 grid gap-4">
            <Field label="ESP host" hint="IP or http://192.168.x.x — CORS must allow this origin.">
              <Input
                value={tank.espHost}
                onChange={(e) => save({ espHost: e.target.value })}
                placeholder="192.168.1.50"
              />
            </Field>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="secondary"
                onClick={() => {
                  void pollLive(tank.id);
                  toast("Polling ESP…");
                }}
              >
                Poll now
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  const next: Tank = {
                    id: uid("tank"),
                    name: "New tank",
                    heightCm: 150,
                    capacityL: 500,
                    deviceId: uid("ESP").toUpperCase(),
                    espHost: "192.168.1.60",
                    mode: "demo",
                    lowThreshold: 25,
                    fullThreshold: 95,
                    sensorOffsetCm: 5,
                  };
                  upsertTank(next);
                  selectTank(next.id);
                  toast("Tank added");
                }}
              >
                Add tank
              </Button>
              {tanks.length > 1 ? (
                <Button
                  variant="ghost"
                  onClick={() => {
                    removeTank(tank.id);
                    toast("Tank removed");
                  }}
                >
                  Remove
                </Button>
              ) : null}
            </div>
          </div>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Paste a reading</CardTitle>
          <CardDesc>
            Same JSON the firmware returns. Useful while you wait for the board, or if the browser
            cannot reach the LAN.
          </CardDesc>
        </CardHeader>
        <Textarea
          className="font-mono text-xs"
          value={jsonText}
          onChange={(e) => setJsonText(e.target.value)}
        />
        <Button
          className="mt-3"
          variant="secondary"
          onClick={() => {
            try {
              const err = applyManualJson(tank.id, JSON.parse(jsonText));
              if (err) toast(err);
              else toast("Reading applied");
            } catch {
              toast("Invalid JSON");
            }
          }}
        >
          Apply JSON
        </Button>
      </Card>

      <Card className="mt-4">
        <CardHeader className="flex-row flex-wrap items-center justify-between gap-3">
          <div>
            <CardTitle>ESP32 sketch</CardTitle>
            <CardDesc>TRIG GPIO 5, ECHO GPIO 18, DHT GPIO 4. Copy into Arduino IDE.</CardDesc>
          </div>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              void navigator.clipboard.writeText(ESP32_SKETCH);
              toast("Sketch copied");
            }}
          >
            Copy sketch
          </Button>
        </CardHeader>
        <pre className="max-h-80 overflow-auto whitespace-pre-wrap break-words rounded-xl bg-background p-4 font-mono text-xs leading-relaxed text-muted">
          {ESP32_SKETCH}
        </pre>
      </Card>
    </AppShell>
  );
}
