import { useMemo } from "react";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { HistoryRange, Reading } from "@/lib/types";
import { rangeMs } from "@/lib/store";
import { formatClock, formatDayTime } from "@/lib/utils";

function downsample(rows: Reading[], max = 96): Reading[] {
  if (rows.length <= max) return rows;
  const step = Math.ceil(rows.length / max);
  const out: Reading[] = [];
  for (let i = 0; i < rows.length; i += step) {
    const row = rows[i];
    if (row) out.push(row);
  }
  const last = rows[rows.length - 1];
  if (last && out[out.length - 1] !== last) out.push(last);
  return out;
}

export function LevelChart({
  history,
  range,
}: {
  history: Reading[];
  range: HistoryRange;
}) {
  const data = useMemo(() => {
    const from = Date.now() - rangeMs(range);
    return downsample(history.filter((r) => r.ts >= from)).map((r) => ({
      ts: r.ts,
      percent: r.percent,
      temp: r.tempC,
      liters: r.liters,
    }));
  }, [history, range]);

  const tickFmt =
    range === "24h"
      ? formatClock
      : (ts: number) => formatDayTime(ts).replace(",", "");

  return (
    <div className="h-56 w-full min-w-0 sm:h-64">
      {data.length < 2 ? (
        <div className="flex h-full items-center justify-center text-sm text-muted">
          History will appear after the first few readings.
        </div>
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="lvl" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#5ec4bc" stopOpacity={0.55} />
                <stop offset="100%" stopColor="#5ec4bc" stopOpacity={0.06} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="rgb(232 238 240 / 0.1)" vertical={false} />
            <XAxis
              dataKey="ts"
              tickFormatter={tickFmt}
              stroke="#8b9aa2"
              tick={{ fill: "#8b9aa2", fontSize: 11 }}
              tickLine={false}
              axisLine={false}
              minTickGap={28}
            />
            <YAxis
              yAxisId="lvl"
              domain={[0, 100]}
              stroke="#8b9aa2"
              tick={{ fill: "#8b9aa2", fontSize: 11 }}
              tickLine={false}
              axisLine={false}
              width={32}
              tickFormatter={(v: number) => `${v}`}
            />
            <YAxis
              yAxisId="temp"
              orientation="right"
              domain={[15, 40]}
              stroke="#8b9aa2"
              tick={{ fill: "#8b9aa2", fontSize: 11 }}
              tickLine={false}
              axisLine={false}
              width={36}
              tickFormatter={(v: number) => `${v}°`}
            />
            <Tooltip
              contentStyle={{
                background: "#12181c",
                border: "1px solid rgb(232 238 240 / 0.1)",
                borderRadius: 12,
                fontSize: 12,
                color: "#e8eef0",
              }}
              labelFormatter={(v) => formatDayTime(Number(v))}
              formatter={(value, name) => {
                const n = typeof value === "number" ? value : Number(value);
                if (name === "percent") return [`${n}%`, "Level"];
                if (name === "temp") return [`${n}°C`, "Temp"];
                return [String(value ?? ""), String(name)];
              }}
            />
            <Area
              yAxisId="lvl"
              type="monotone"
              dataKey="percent"
              stroke="#5ec4bc"
              strokeWidth={2.5}
              fill="url(#lvl)"
              dot={false}
              isAnimationActive={false}
            />
            <Line
              yAxisId="temp"
              type="monotone"
              dataKey="temp"
              stroke="#e0a36a"
              strokeWidth={2}
              dot={false}
              isAnimationActive={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
