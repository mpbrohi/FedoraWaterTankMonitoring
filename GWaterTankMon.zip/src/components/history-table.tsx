import type { Reading } from "@/lib/types";
import { formatDayTime } from "@/lib/utils";

export function HistoryTable({ rows }: { rows: Reading[] }) {
  const slice = rows.slice(-12).reverse();
  if (!slice.length) {
    return <p className="text-sm text-muted">No readings stored yet.</p>;
  }
  return (
    <div className="min-w-0 overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="text-xs uppercase tracking-wide text-muted">
            <th className="py-2 pr-3 font-medium">Time</th>
            <th className="py-2 pr-3 font-medium">Level</th>
            <th className="py-2 pr-3 font-medium">Water</th>
            <th className="py-2 pr-3 font-medium">Empty</th>
            <th className="py-2 pr-3 font-medium">Temp</th>
            <th className="py-2 font-medium">Source</th>
          </tr>
        </thead>
        <tbody>
          {slice.map((r) => (
            <tr key={r.ts} className="border-t border-border">
              <td className="whitespace-nowrap py-2.5 pr-3 font-mono text-xs tabular-nums text-muted">
                {formatDayTime(r.ts)}
              </td>
              <td className="py-2.5 pr-3 font-mono tabular-nums">{r.percent}%</td>
              <td className="py-2.5 pr-3 font-mono tabular-nums">{r.levelCm.toFixed(1)} cm</td>
              <td className="py-2.5 pr-3 font-mono tabular-nums">{r.distanceCm.toFixed(1)} cm</td>
              <td className="py-2.5 pr-3 font-mono tabular-nums">
                {r.tempC == null ? "—" : `${r.tempC.toFixed(1)}°`}
              </td>
              <td className="py-2.5 capitalize text-muted">{r.source}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
