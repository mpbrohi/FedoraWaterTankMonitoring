import { cn } from "@/lib/utils";

export function TempGauge({
  tempC,
  humidity,
  className,
}: {
  tempC: number | null;
  humidity: number | null;
  className?: string;
}) {
  const t = tempC ?? 0;
  const min = 10;
  const max = 45;
  const ratio = tempC == null ? 0 : Math.min(1, Math.max(0, (t - min) / (max - min)));
  const r = 42;
  const c = 2 * Math.PI * r;
  const dash = c * 0.75;
  const offset = dash * (1 - ratio);

  return (
    <div className={cn("flex min-w-0 items-center gap-4", className)}>
      <svg viewBox="0 0 120 120" className="size-24 shrink-0" aria-hidden="true">
        <g transform="rotate(135 60 60)">
          <circle
            cx="60"
            cy="60"
            r={r}
            fill="none"
            stroke="#1c262c"
            strokeWidth="8"
            strokeDasharray={`${dash} ${c}`}
            strokeLinecap="round"
          />
          <circle
            cx="60"
            cy="60"
            r={r}
            fill="none"
            stroke="#2f8f86"
            strokeWidth="8"
            strokeDasharray={`${dash} ${c}`}
            strokeDashoffset={offset}
            strokeLinecap="round"
            style={{ transition: "stroke-dashoffset 700ms cubic-bezier(0.22, 1, 0.36, 1)" }}
          />
        </g>
        <text
          x="60"
          y="58"
          textAnchor="middle"
          fill="#e8eef0"
          fontSize="22"
          fontFamily="IBM Plex Mono, ui-monospace, monospace"
          fontWeight="500"
        >
          {tempC == null ? "—" : t.toFixed(1)}
        </text>
        <text
          x="60"
          y="76"
          textAnchor="middle"
          fill="#8b9aa2"
          fontSize="11"
          fontFamily="Outfit, sans-serif"
        >
          °C
        </text>
      </svg>
      <div className="min-w-0">
        <p className="text-sm font-medium text-foreground">Temperature</p>
        <p className="mt-1 text-sm leading-normal text-muted">
          DHT / DS18B20 on the ESP. {humidity == null ? "Humidity unavailable." : `Humidity ${humidity.toFixed(0)}%.`}
        </p>
      </div>
    </div>
  );
}
