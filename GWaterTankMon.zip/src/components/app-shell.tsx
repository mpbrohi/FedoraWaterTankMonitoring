import { useEffect, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Activity, Bell, Cpu, Droplets, Settings } from "lucide-react";
import { Toaster } from "sonner";
import { useTankStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Monitor", icon: Activity },
  { to: "/alerts", label: "Alerts", icon: Bell },
  { to: "/device", label: "Device", icon: Cpu },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hydrate = useTankStore((s) => s.hydrate);
  const hydrated = useTankStore((s) => s.hydrated);
  const tanks = useTankStore((s) => s.tanks);
  const settings = useTankStore((s) => s.settings);
  const tickDemo = useTankStore((s) => s.tickDemo);
  const pollLive = useTankStore((s) => s.pollLive);
  const unread = useTankStore((s) => s.alerts.filter((a) => !a.read).length);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!hydrated) return;
    const tick = () => {
      for (const t of useTankStore.getState().tanks) {
        if (t.mode === "demo") tickDemo(t.id);
        else void pollLive(t.id);
      }
    };
    tick();
    const id = window.setInterval(tick, Math.max(2, settings.pollSeconds) * 1000);
    return () => window.clearInterval(id);
  }, [hydrated, settings.pollSeconds, tickDemo, pollLive, tanks.length]);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <header className="sticky top-0 z-20 border-b border-border bg-background/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex min-w-0 items-center gap-2.5">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-md bg-card-2 text-accent shadow-[var(--shadow-border)]">
              <Droplets className="size-4" strokeWidth={1.75} />
            </span>
            <span className="min-w-0">
              <span className="block truncate text-sm font-medium leading-tight">AquaLevel</span>
              <span className="block truncate text-xs text-muted">ESP + ultrasonic</span>
            </span>
          </Link>
          <nav className="ml-auto hidden items-center gap-1 md:flex">
            {NAV.map((item) => {
              const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "relative flex h-11 items-center gap-2 rounded-md px-3 text-sm transition-colors duration-150",
                    active ? "bg-card-2 text-foreground" : "text-muted hover:text-foreground",
                  )}
                >
                  <Icon className="size-4 shrink-0" strokeWidth={1.75} />
                  {item.label}
                  {item.to === "/alerts" && unread > 0 ? (
                    <span className="rounded-full bg-danger px-1.5 py-0.5 font-mono text-xs text-foreground">
                      {unread}
                    </span>
                  ) : null}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-6 md:pb-12">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden">
        <ul className="grid grid-cols-4">
          {NAV.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "relative flex min-h-14 flex-col items-center justify-center gap-1 px-1 text-xs leading-none",
                    active ? "text-foreground" : "text-muted",
                  )}
                >
                  <Icon className="size-5" strokeWidth={1.75} />
                  <span className="max-w-full truncate">{item.label}</span>
                  {item.to === "/alerts" && unread > 0 ? (
                    <span className="absolute right-1/4 top-2 size-1.5 rounded-full bg-danger" />
                  ) : null}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <Toaster theme="dark" position="top-center" richColors={false} />
    </div>
  );
}
