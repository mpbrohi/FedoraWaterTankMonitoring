import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function StatTile({
  icon: Icon,
  label,
  value,
  hint,
  className,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  hint?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex min-w-0 items-start gap-3 rounded-xl bg-card-2 p-4 shadow-[var(--shadow-border)]",
        className,
      )}
    >
      <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md bg-background text-accent">
        <Icon className="size-4" strokeWidth={1.75} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-medium uppercase tracking-wide text-muted">{label}</p>
        <p className="mt-1 break-words font-mono text-lg font-medium tabular-nums leading-snug text-foreground">
          {value}
        </p>
        {hint ? <p className="mt-1 text-xs leading-normal text-muted">{hint}</p> : null}
      </div>
    </div>
  );
}
