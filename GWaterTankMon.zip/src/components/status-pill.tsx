import { Badge } from "@/components/ui/badge";
import type { TankStatus } from "@/lib/types";

const MAP: Record<TankStatus, { label: string; tone: "ok" | "warn" | "danger" | "accent" | "neutral" }> = {
  normal: { label: "Normal", tone: "ok" },
  low: { label: "Low water", tone: "danger" },
  full: { label: "Full", tone: "accent" },
  offline: { label: "Offline", tone: "neutral" },
  fault: { label: "Sensor fault", tone: "warn" },
};

export function StatusPill({ status }: { status: TankStatus }) {
  const m = MAP[status];
  return <Badge tone={m.tone}>{m.label}</Badge>;
}
