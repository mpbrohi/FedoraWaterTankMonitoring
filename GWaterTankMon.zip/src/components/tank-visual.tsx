import { cn } from "@/lib/utils";
import type { TankStatus } from "@/lib/types";

const INNER_TOP = 62;
const INNER_BOTTOM = 348;
const INNER_HEIGHT = INNER_BOTTOM - INNER_TOP;

function waterColor(status: TankStatus, percent: number): { fill: string; deep: string } {
  if (status === "offline" || status === "fault") {
    return { fill: "#4a5560", deep: "#2a3238" };
  }
  if (percent <= 20 || status === "low") {
    return { fill: "#c45c52", deep: "#7a2e2a" };
  }
  if (percent >= 90 || status === "full") {
    return { fill: "#3d9b8f", deep: "#1a5f6b" };
  }
  return { fill: "#2a8f9e", deep: "#164e58" };
}

export function TankVisual({
  percent,
  levelCm,
  heightCm,
  status,
  className,
}: {
  percent: number;
  levelCm: number;
  heightCm: number;
  status: TankStatus;
  className?: string;
}) {
  const p = Math.max(0, Math.min(100, percent));
  const shift = ((100 - p) / 100) * INNER_HEIGHT;
  const { fill, deep } = waterColor(status, p);
  const ticks = [0, 25, 50, 75, 100];

  return (
    <div className={cn("relative mx-auto w-full max-w-52 select-none sm:max-w-xs", className)}>
      <svg
        viewBox="0 0 280 420"
        className="h-auto w-full overflow-visible"
        role="img"
        aria-label={`Tank at ${Math.round(p)} percent, ${levelCm} centimetres of ${heightCm}`}
      >
        <defs>
          <linearGradient id="shell" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stopColor="#1a2228" />
            <stop offset="35%" stopColor="#2a343c" />
            <stop offset="65%" stopColor="#232c32" />
            <stop offset="100%" stopColor="#151c21" />
          </linearGradient>
          <linearGradient id="water" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={fill} stopOpacity="0.92" />
            <stop offset="100%" stopColor={deep} stopOpacity="1" />
          </linearGradient>
          <linearGradient id="shine" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stopColor="#fff" stopOpacity="0" />
            <stop offset="22%" stopColor="#fff" stopOpacity="0.1" />
            <stop offset="40%" stopColor="#fff" stopOpacity="0" />
          </linearGradient>
          <clipPath id="tank-inner">
            <rect x="58" y={INNER_TOP} width="132" height={INNER_HEIGHT} rx="8" />
          </clipPath>
        </defs>

        {/* Floor shadow */}
        <ellipse cx="124" cy="392" rx="78" ry="10" fill="#000" opacity="0.35" />

        {/* Outlet pipe */}
        <rect x="188" y="328" width="28" height="10" rx="3" fill="#1c242a" />
        <rect x="212" y="322" width="10" height="22" rx="3" fill="#243038" />

        {/* Tank shell */}
        <rect x="50" y="54" width="148" height="304" rx="18" fill="url(#shell)" stroke="#3a464e" strokeWidth="1.4" />
        <rect x="56" y="60" width="136" height="292" rx="14" fill="#0d1317" stroke="#2a343c" strokeWidth="1" />

        {/* Hoops */}
        {[110, 190, 270].map((y) => (
          <rect key={y} x="48" y={y} width="152" height="6" rx="2" fill="#1c262c" opacity="0.9" />
        ))}

        {/* Water */}
        <g clipPath="url(#tank-inner)">
          <g
            className="tank-water"
            style={{
              transform: `translateY(${shift}px)`,
              transition: "transform 900ms cubic-bezier(0.22, 1, 0.36, 1)",
            }}
          >
            <rect x="58" y={INNER_TOP - 20} width="132" height={INNER_HEIGHT + 40} fill="url(#water)" />
            <g className="wave-a" style={{ transformOrigin: "58px 0" }}>
              <path
                d="M28 70 C 50 58, 72 82, 94 70 S 138 58, 160 70 S 204 82, 226 70 V 90 H 28 Z"
                fill={fill}
                opacity="0.85"
              />
            </g>
            <g className="wave-b" style={{ transformOrigin: "58px 0" }}>
              <path
                d="M28 76 C 54 88, 78 64, 104 76 S 150 88, 176 76 S 214 64, 236 76 V 96 H 28 Z"
                fill="#d7f4f2"
                opacity="0.18"
              />
            </g>
            <circle className="bubble" cx="88" cy="280" r="3" fill="#fff" opacity="0.35" />
            <circle
              className="bubble"
              cx="142"
              cy="250"
              r="2.2"
              fill="#fff"
              opacity="0.3"
              style={{ animationDelay: "1.4s", animationDuration: "6.4s" }}
            />
            <circle
              className="bubble"
              cx="118"
              cy="310"
              r="2.6"
              fill="#fff"
              opacity="0.28"
              style={{ animationDelay: "2.6s", animationDuration: "7s" }}
            />
            <rect x="58" y={INNER_TOP - 20} width="132" height={INNER_HEIGHT + 40} fill="url(#shine)" />
          </g>
        </g>

        {/* Glass highlight */}
        <rect x="64" y="72" width="10" height="250" rx="5" fill="#fff" opacity="0.05" />

        {/* Lid + ultrasonic sensor */}
        <rect x="44" y="40" width="160" height="18" rx="6" fill="#2a343c" stroke="#445058" strokeWidth="1" />
        <rect x="96" y="18" width="56" height="26" rx="6" fill="#1a2228" stroke="#3a464e" strokeWidth="1" />
        <circle cx="112" cy="31" r="5" fill="#0d1317" stroke="#2f8f86" strokeWidth="1.4" />
        <circle cx="136" cy="31" r="5" fill="#0d1317" stroke="#2f8f86" strokeWidth="1.4" />
        <line x1="124" y1="18" x2="124" y2="10" stroke="#3a464e" strokeWidth="2" />
        <circle cx="124" cy="8" r="3" fill="#2f8f86" />

        {/* Sight glass */}
        <rect x="204" y="70" width="16" height="270" rx="6" fill="#0d1317" stroke="#3a464e" strokeWidth="1" />
        <rect
          x="206"
          y={70 + ((100 - p) / 100) * 266}
          width="12"
          height={(p / 100) * 266}
          rx="4"
          fill={fill}
          style={{ transition: "y 900ms cubic-bezier(0.22, 1, 0.36, 1), height 900ms cubic-bezier(0.22, 1, 0.36, 1)" }}
        />

        {/* Scale ticks */}
        {ticks.map((t) => {
          const y = INNER_BOTTOM - (t / 100) * INNER_HEIGHT;
          return (
            <g key={t}>
              <line x1="222" y1={y} x2="232" y2={y} stroke="#8b9aa2" strokeWidth="1" />
              <text
                x="236"
                y={y + 4}
                fill="#8b9aa2"
                fontSize="11"
                fontFamily="IBM Plex Mono, ui-monospace, monospace"
              >
                {t}
              </text>
            </g>
          );
        })}

        {/* Current level pointer */}
        <polygon
          points={`200,${INNER_BOTTOM - (p / 100) * INNER_HEIGHT} 208,${INNER_BOTTOM - (p / 100) * INNER_HEIGHT - 5} 208,${INNER_BOTTOM - (p / 100) * INNER_HEIGHT + 5}`}
          fill="#e8eef0"
          style={{ transition: "all 900ms cubic-bezier(0.22, 1, 0.36, 1)" }}
        />
      </svg>

      <div className="pointer-events-none absolute inset-x-0 top-1/2 flex -translate-y-8 flex-col items-center px-8 text-center">
        <p className="font-mono text-3xl font-medium tabular-nums tracking-tight text-foreground drop-shadow-[0_2px_12px_rgba(0,0,0,0.65)] sm:text-4xl">
          {Math.round(p)}
          <span className="text-xl text-muted">%</span>
        </p>
        <p className="mt-1 max-w-full font-mono text-sm tabular-nums text-muted">
          {levelCm.toFixed(1)} / {heightCm} cm
        </p>
      </div>
    </div>
  );
}
