import { create } from "zustand";
import type {
  Alert,
  AlertType,
  HistoryRange,
  Reading,
  Settings,
  Tank,
  TankStatus,
} from "./types";
import { fetchEsp, parseEspPayload, readingFromDistance } from "./esp";
import { clamp, round1, uid } from "./utils";

const STORAGE_KEY = "aqualevel-v2";

function defaultTanks(): Tank[] {
  return [
    {
      id: "tank-roof",
      name: "Roof Tank",
      heightCm: 180,
      capacityL: 1000,
      deviceId: "ESP-ROOF-01",
      espHost: "192.168.1.50",
      mode: "demo",
      lowThreshold: 25,
      fullThreshold: 95,
      sensorOffsetCm: 5,
    },
    {
      id: "tank-ground",
      name: "Ground Tank",
      heightCm: 200,
      capacityL: 2000,
      deviceId: "ESP-GND-01",
      espHost: "192.168.1.51",
      mode: "demo",
      lowThreshold: 20,
      fullThreshold: 95,
      sensorOffsetCm: 8,
    },
  ];
}

function seedHistory(tank: Tank, now: number): Reading[] {
  const out: Reading[] = [];
  let percent = tank.id.includes("ground") ? 48 : 72;
  let temp = tank.id.includes("ground") ? 26.1 : 29.4;
  let hum = 58;
  const end = now;
  const start = now - 30 * 24 * 3600 * 1000;
  let ts = start;
  while (ts <= end) {
    const ageMs = end - ts;
    const step =
      ageMs > 7 * 24 * 3600 * 1000
        ? 3 * 3600 * 1000
        : ageMs > 24 * 3600 * 1000
          ? 3600 * 1000
          : 15 * 60 * 1000;
    const hourScale = step / 3600000;
    const hour = new Date(ts).getHours();
    if (hour >= 6 && hour <= 9) percent -= (0.55 + Math.random() * 0.7) * hourScale;
    else if (hour >= 18 && hour <= 21) percent -= (0.45 + Math.random() * 0.55) * hourScale;
    else if (hour >= 11 && hour <= 13) percent += (1.1 + Math.random() * 1.2) * hourScale;
    else percent += (Math.random() - 0.48) * 0.25 * hourScale;
    percent = clamp(percent, 14, 97);
    temp += (Math.random() - 0.5) * 0.22 * Math.min(hourScale, 2);
    temp = clamp(temp, 22, 36);
    hum += (Math.random() - 0.5) * 0.8 * Math.min(hourScale, 2);
    hum = clamp(hum, 35, 82);
    const usable = tank.heightCm - tank.sensorOffsetCm;
    const levelCm = (percent / 100) * usable;
    const distanceCm = tank.sensorOffsetCm + (usable - levelCm);
    out.push({
      ts,
      distanceCm: round1(distanceCm),
      levelCm: round1(levelCm),
      percent: Math.round(percent),
      liters: Math.round((percent / 100) * tank.capacityL),
      tempC: round1(temp),
      humidity: round1(hum),
      rssi: -48 - Math.round(Math.random() * 16),
      online: true,
      source: "demo",
    });
    ts += step;
  }
  return out;
}


function seedAlerts(tanks: Tank[], now: number): Alert[] {
  const roof = tanks[0];
  const ground = tanks[1];
  if (!roof || !ground) return [];
  return [
    {
      id: "a1",
      tankId: ground.id,
      type: "low_water",
      message: `${ground.name} dropped below ${ground.lowThreshold}% during evening use`,
      ts: now - 3 * 3600 * 1000,
      read: false,
    },
    {
      id: "a2",
      tankId: roof.id,
      type: "tank_full",
      message: `${roof.name} reached full after the noon motor run`,
      ts: now - 28 * 3600 * 1000,
      read: true,
    },
    {
      id: "a3",
      tankId: roof.id,
      type: "device_offline",
      message: `${roof.name} ESP missed two poll cycles`,
      ts: now - 52 * 3600 * 1000,
      read: true,
    },
  ];
}

export function tankStatus(tank: Tank, reading: Reading | undefined): TankStatus {
  if (!reading || !reading.online) return "offline";
  if (reading.distanceCm < 0) return "fault";
  if (reading.percent >= tank.fullThreshold) return "full";
  if (reading.percent <= tank.lowThreshold) return "low";
  return "normal";
}

export function rangeMs(range: HistoryRange): number {
  if (range === "24h") return 24 * 3600 * 1000;
  if (range === "7d") return 7 * 24 * 3600 * 1000;
  return 30 * 24 * 3600 * 1000;
}

interface Persisted {
  tanks: Tank[];
  selectedId: string;
  history: Record<string, Reading[]>;
  latest: Record<string, Reading>;
  alerts: Alert[];
  settings: Settings;
}

interface TankState extends Persisted {
  hydrated: boolean;
  pollError: Record<string, string | null>;
  hydrate: () => void;
  selectTank: (id: string) => void;
  upsertTank: (tank: Tank) => void;
  removeTank: (id: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  markAlertRead: (id: string) => void;
  markAllRead: () => void;
  clearAlerts: () => void;
  ingest: (tankId: string, reading: Reading, error?: string | null) => void;
  applyManualJson: (tankId: string, raw: unknown) => string | null;
  tickDemo: (tankId: string) => void;
  pollLive: (tankId: string) => Promise<void>;
}

const defaultSettings: Settings = {
  pollSeconds: 4,
  notifications: false,
  tempWarnC: 40,
};

function persist(s: Persisted) {
  if (typeof window === "undefined") return;
  const payload: Persisted = {
    tanks: s.tanks,
    selectedId: s.selectedId,
    history: s.history,
    latest: s.latest,
    alerts: s.alerts.slice(0, 80),
    settings: s.settings,
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch {
    /* quota */
  }
}

function load(): Persisted | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Persisted;
  } catch {
    return null;
  }
}

function fresh(): Persisted {
  const tanks = defaultTanks();
  const now = Date.now();
  const history: Record<string, Reading[]> = {};
  const latest: Record<string, Reading> = {};
  for (const tank of tanks) {
    const series = seedHistory(tank, now);
    history[tank.id] = series;
    const last = series[series.length - 1];
    if (last) latest[tank.id] = last;
  }
  return {
    tanks,
    selectedId: tanks[0]?.id ?? "",
    history,
    latest,
    alerts: seedAlerts(tanks, now),
    settings: defaultSettings,
  };
}

function pushHistory(
  history: Record<string, Reading[]>,
  tankId: string,
  reading: Reading,
): Record<string, Reading[]> {
  const prev = history[tankId] ?? [];
  const last = prev[prev.length - 1];
  if (last && reading.ts - last.ts < 8000) {
    return { ...history, [tankId]: [...prev.slice(0, -1), reading] };
  }
  const next = [...prev, reading];
  const cutoff = Date.now() - 32 * 24 * 3600 * 1000;
  const trimmed = next.filter((r) => r.ts >= cutoff).slice(-1400);
  return { ...history, [tankId]: trimmed };
}

function maybeAlerts(
  tank: Tank,
  reading: Reading,
  prev: Reading | undefined,
  settings: Settings,
): Alert[] {
  const out: Alert[] = [];
  const add = (type: AlertType, message: string) => {
    out.push({
      id: uid("al"),
      tankId: tank.id,
      type,
      message,
      ts: reading.ts,
      read: false,
    });
  };
  const crossed = (key: (r: Reading) => boolean) =>
    !prev || key(prev) !== key(reading);

  if (!reading.online && (!prev || prev.online)) {
    add("device_offline", `${tank.name} ESP is unreachable`);
  }
  if (
    reading.online &&
    reading.percent <= tank.lowThreshold &&
    crossed((r) => r.percent <= tank.lowThreshold && r.online)
  ) {
    add(
      "low_water",
      `${tank.name} is at ${reading.percent}% (${reading.levelCm} cm)`,
    );
  }
  if (
    reading.online &&
    reading.percent >= tank.fullThreshold &&
    crossed((r) => r.percent >= tank.fullThreshold && r.online)
  ) {
    add("tank_full", `${tank.name} is full (${reading.percent}%)`);
  }
  if (reading.distanceCm < 0) {
    add("sensor_fault", `${tank.name} ultrasonic echo timed out`);
  }
  if (
    reading.tempC != null &&
    reading.tempC >= settings.tempWarnC &&
    (!prev || prev.tempC == null || prev.tempC < settings.tempWarnC)
  ) {
    add("high_temp", `${tank.name} sensor reads ${reading.tempC}°C`);
  }
  return out;
}

export const useTankStore = create<TankState>((set, get) => ({
  ...fresh(),
  hydrated: false,
  pollError: {},

  hydrate: () => {
    const saved = load();
    if (saved?.tanks?.length) {
      set({
        ...saved,
        settings: { ...defaultSettings, ...saved.settings },
        hydrated: true,
        pollError: {},
      });
    } else {
      const next = fresh();
      persist(next);
      set({ ...next, hydrated: true, pollError: {} });
    }
  },

  selectTank: (id) => {
    set({ selectedId: id });
    persist(get());
  },

  upsertTank: (tank) => {
    const { tanks, history, latest, selectedId } = get();
    const exists = tanks.some((t) => t.id === tank.id);
    const nextTanks = exists
      ? tanks.map((t) => (t.id === tank.id ? tank : t))
      : [...tanks, tank];
    const nextHistory = history[tank.id]
      ? history
      : { ...history, [tank.id]: seedHistory(tank, Date.now()) };
    const last = nextHistory[tank.id]?.at(-1);
    const nextLatest = latest[tank.id]
      ? latest
      : last
        ? { ...latest, [tank.id]: last }
        : latest;
    set({
      tanks: nextTanks,
      history: nextHistory,
      latest: nextLatest,
      selectedId: selectedId || tank.id,
    });
    persist(get());
  },

  removeTank: (id) => {
    const { tanks, history, latest, alerts, selectedId } = get();
    const nextTanks = tanks.filter((t) => t.id !== id);
    const { [id]: _h, ...restH } = history;
    const { [id]: _l, ...restL } = latest;
    void _h;
    void _l;
    set({
      tanks: nextTanks,
      history: restH,
      latest: restL,
      alerts: alerts.filter((a) => a.tankId !== id),
      selectedId: selectedId === id ? (nextTanks[0]?.id ?? "") : selectedId,
    });
    persist(get());
  },

  updateSettings: (patch) => {
    set({ settings: { ...get().settings, ...patch } });
    persist(get());
  },

  markAlertRead: (id) => {
    set({
      alerts: get().alerts.map((a) => (a.id === id ? { ...a, read: true } : a)),
    });
    persist(get());
  },

  markAllRead: () => {
    set({ alerts: get().alerts.map((a) => ({ ...a, read: true })) });
    persist(get());
  },

  clearAlerts: () => {
    set({ alerts: [] });
    persist(get());
  },

  ingest: (tankId, reading, error = null) => {
    const { tanks, history, latest, alerts, settings, pollError } = get();
    const tank = tanks.find((t) => t.id === tankId);
    if (!tank) return;
    const prev = latest[tankId];
    const extra = maybeAlerts(tank, reading, prev, settings);
    set({
      history: pushHistory(history, tankId, reading),
      latest: { ...latest, [tankId]: reading },
      alerts: [...extra, ...alerts].slice(0, 80),
      pollError: { ...pollError, [tankId]: error },
    });
    persist(get());
    if (
      settings.notifications &&
      extra.length &&
      typeof window !== "undefined" &&
      "Notification" in window &&
      Notification.permission === "granted"
    ) {
      const first = extra[0];
      if (first) new Notification("AquaLevel", { body: first.message });
    }
  },

  applyManualJson: (tankId, raw) => {
    const tank = get().tanks.find((t) => t.id === tankId);
    if (!tank) return "Tank not found";
    const parsed = parseEspPayload(raw);
    if (!parsed) return "JSON must include distance_cm (or distance)";
    get().ingest(tankId, readingFromDistance(tank, parsed, "manual"));
    return null;
  },

  tickDemo: (tankId) => {
    const { tanks, latest } = get();
    const tank = tanks.find((t) => t.id === tankId);
    if (!tank || tank.mode !== "demo") return;
    const prev = latest[tankId];
    const usable = tank.heightCm - tank.sensorOffsetCm;
    let percent = prev?.percent ?? 60;
    percent = clamp(percent + (Math.random() - 0.46) * 1.15, 8, 98);
    const levelCm = (percent / 100) * usable;
    const distanceCm = tank.sensorOffsetCm + (usable - levelCm);
    let temp = prev?.tempC ?? 27;
    temp = clamp(temp + (Math.random() - 0.5) * 0.18, 22, 36);
    let hum = prev?.humidity ?? 55;
    hum = clamp(hum + (Math.random() - 0.5) * 0.6, 30, 85);
    get().ingest(tankId, {
      ts: Date.now(),
      distanceCm: round1(distanceCm),
      levelCm: round1(levelCm),
      percent: Math.round(percent),
      liters: Math.round((percent / 100) * tank.capacityL),
      tempC: round1(temp),
      humidity: round1(hum),
      rssi: prev?.rssi ?? -55,
      online: true,
      source: "demo",
    });
  },

  pollLive: async (tankId) => {
    const tank = get().tanks.find((t) => t.id === tankId);
    if (!tank || tank.mode !== "live") return;
    const prev = get().latest[tankId];
    try {
      const payload = await fetchEsp(tank.espHost);
      get().ingest(tankId, readingFromDistance(tank, payload, "esp"));
    } catch (err) {
      const message = err instanceof Error ? err.message : "ESP unreachable";
      const offline: Reading = prev
        ? { ...prev, ts: Date.now(), online: false, source: "esp" }
        : {
            ts: Date.now(),
            distanceCm: 0,
            levelCm: 0,
            percent: 0,
            liters: 0,
            tempC: null,
            humidity: null,
            rssi: null,
            online: false,
            source: "esp",
          };
      get().ingest(tankId, offline, message);
    }
  },
}));

export function selectedTank(s: Pick<TankState, "tanks" | "selectedId">): Tank | undefined {
  return s.tanks.find((t) => t.id === s.selectedId) ?? s.tanks[0];
}
