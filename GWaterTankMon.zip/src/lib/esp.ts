import type { EspPayload, Reading, Tank } from "./types";
import { clamp, round1 } from "./utils";

function num(v: unknown): number | null {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.trim() !== "") {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

function pick(obj: Record<string, unknown>, keys: string[]): number | null {
  for (const k of keys) {
    if (k in obj) {
      const n = num(obj[k]);
      if (n != null) return n;
    }
  }
  return null;
}

export function parseEspPayload(raw: unknown): EspPayload | null {
  if (!raw || typeof raw !== "object") return null;
  const obj = raw as Record<string, unknown>;
  const nested =
    obj.data && typeof obj.data === "object"
      ? (obj.data as Record<string, unknown>)
      : obj;

  const distanceCm = pick(nested, [
    "distance_cm",
    "distanceCm",
    "distance",
    "dist",
    "empty_cm",
    "emptyCm",
    "cm",
  ]);
  if (distanceCm == null) return null;

  return {
    distanceCm,
    tempC: pick(nested, [
      "temperature_c",
      "temperatureC",
      "temperature",
      "tempC",
      "temp",
    ]),
    humidity: pick(nested, ["humidity", "hum", "rh"]),
    rssi: pick(nested, ["rssi", "wifi", "signal", "wifi_rssi"]),
  };
}

export function readingFromDistance(
  tank: Tank,
  payload: EspPayload,
  source: Reading["source"],
  ts = Date.now(),
): Reading {
  const usableHeight = Math.max(1, tank.heightCm - tank.sensorOffsetCm);
  const empty = clamp(payload.distanceCm - tank.sensorOffsetCm, 0, usableHeight);
  const levelCm = round1(usableHeight - empty);
  const percent = clamp(Math.round((levelCm / usableHeight) * 100), 0, 100);
  const liters = Math.round((percent / 100) * tank.capacityL);
  return {
    ts,
    distanceCm: round1(payload.distanceCm),
    levelCm,
    percent,
    liters,
    tempC: payload.tempC != null ? round1(payload.tempC) : null,
    humidity: payload.humidity != null ? round1(payload.humidity) : null,
    rssi: payload.rssi != null ? Math.round(payload.rssi) : null,
    online: true,
    source,
  };
}

export function statusUrl(host: string): string {
  const trimmed = host.trim().replace(/\/$/, "");
  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed.endsWith("/status") ? trimmed : `${trimmed}/status`;
  }
  return `http://${trimmed}/status`;
}

export async function fetchEsp(host: string, timeoutMs = 4000): Promise<EspPayload> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(statusUrl(host), {
      signal: ctrl.signal,
      cache: "no-store",
      headers: { Accept: "application/json" },
    });
    if (!res.ok) throw new Error(`ESP HTTP ${res.status}`);
    const json: unknown = await res.json();
    const parsed = parseEspPayload(json);
    if (!parsed) throw new Error("ESP JSON missing distance");
    return parsed;
  } finally {
    clearTimeout(timer);
  }
}

export const ESP32_SKETCH = `/*
  AquaLevel — ESP32 + HC-SR04 ultrasonic + DHT11/DHT22
  Arduino IDE: install "DHT sensor library" by Adafruit.

  Wiring
    HC-SR04 TRIG -> GPIO 5
    HC-SR04 ECHO -> GPIO 18   (use a 1k/2k divider if the module is 5V)
    DHT DATA     -> GPIO 4    (optional — temp/humidity)
    VCC 3.3V or 5V as the module requires, GND common
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>

const char* WIFI_SSID = "YOUR_WIFI";
const char* WIFI_PASS = "YOUR_PASSWORD";

const int PIN_TRIG = 5;
const int PIN_ECHO = 18;
const int PIN_DHT  = 4;
#define DHTTYPE DHT11

WebServer server(80);
DHT dht(PIN_DHT, DHTTYPE);

float readDistanceCm() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(4);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  unsigned long us = pulseIn(PIN_ECHO, HIGH, 30000UL);
  if (us == 0) return -1;
  return (us * 0.0343f) / 2.0f;
}

void sendCors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "*");
}

void handleStatus() {
  sendCors();
  float dist = readDistanceCm();
  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();

  String json = "{";
  json += "\\"ok\\":true,";
  json += "\\"distance_cm\\":" + String(dist, 1) + ",";
  if (isnan(temp)) json += "\\"temperature_c\\":null,";
  else             json += "\\"temperature_c\\":" + String(temp, 1) + ",";
  if (isnan(hum))  json += "\\"humidity\\":null,";
  else             json += "\\"humidity\\":" + String(hum, 1) + ",";
  json += "\\"rssi\\":" + String(WiFi.RSSI()) + ",";
  json += "\\"ip\\":\\"" + WiFi.localIP().toString() + "\\",";
  json += "\\"uptime_s\\":" + String(millis() / 1000) + ",";
  json += "\\"firmware\\":\\"aqualevel-1.0\\"";
  json += "}";
  server.send(200, "application/json", json);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  dht.begin();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) delay(400);

  server.on("/status", HTTP_GET, handleStatus);
  server.on("/status", HTTP_OPTIONS, []() {
    sendCors();
    server.send(204);
  });
  server.on("/", []() {
    sendCors();
    server.send(200, "text/plain", "AquaLevel ESP ready. GET /status");
  });
  server.begin();
  Serial.print("AquaLevel http://");
  Serial.print(WiFi.localIP());
  Serial.println("/status");
}

void loop() {
  server.handleClient();
}
`;
