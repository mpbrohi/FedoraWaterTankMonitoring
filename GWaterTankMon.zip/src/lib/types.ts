export type TankMode = "demo" | "live";

export type TankStatus = "normal" | "low" | "full" | "offline" | "fault";

export interface Tank {
  id: string;
  name: string;
  heightCm: number;
  capacityL: number;
  deviceId: string;
  espHost: string;
  mode: TankMode;
  lowThreshold: number;
  fullThreshold: number;
  sensorOffsetCm: number;
}

export interface Reading {
  ts: number;
  distanceCm: number;
  levelCm: number;
  percent: number;
  liters: number;
  tempC: number | null;
  humidity: number | null;
  rssi: number | null;
  online: boolean;
  source: "demo" | "esp" | "manual";
}

export type AlertType =
  | "low_water"
  | "tank_full"
  | "device_offline"
  | "sensor_fault"
  | "high_temp";

export interface Alert {
  id: string;
  tankId: string;
  type: AlertType;
  message: string;
  ts: number;
  read: boolean;
}

export interface Settings {
  pollSeconds: number;
  notifications: boolean;
  tempWarnC: number;
}

export interface EspPayload {
  distanceCm: number;
  tempC: number | null;
  humidity: number | null;
  rssi: number | null;
}

export type HistoryRange = "24h" | "7d" | "30d";
