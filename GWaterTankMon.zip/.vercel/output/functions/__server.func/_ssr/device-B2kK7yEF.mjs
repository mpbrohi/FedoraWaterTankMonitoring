import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as uid, a as CardTitle, h as statusUrl, i as CardHeader, m as selectedTank, n as Card, o as ESP32_SKETCH, r as CardDesc, t as AppShell, v as useTankStore } from "./card-Cd-6sB1a.mjs";
import { t as Button } from "./button-DTwDogWK.mjs";
import { i as Textarea, n as Input, r as Switch, t as Field } from "./switch-DVFrF1V-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/device-B2kK7yEF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DevicePage() {
	const tanks = useTankStore((s) => s.tanks);
	const selectedId = useTankStore((s) => s.selectedId);
	const selectTank = useTankStore((s) => s.selectTank);
	const upsertTank = useTankStore((s) => s.upsertTank);
	const removeTank = useTankStore((s) => s.removeTank);
	const applyManualJson = useTankStore((s) => s.applyManualJson);
	const pollLive = useTankStore((s) => s.pollLive);
	const tank = selectedTank({
		tanks,
		selectedId
	});
	const [jsonText, setJsonText] = (0, import_react.useState)("{\n  \"distance_cm\": 42.0,\n  \"temperature_c\": 28.4,\n  \"humidity\": 61,\n  \"rssi\": -52\n}");
	if (!tank) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Add a tank to configure the ESP."
	}) });
	const save = (patch) => upsertTank({
		...tank,
		...patch
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-medium tracking-tight",
			children: "Device"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 max-w-2xl text-sm leading-normal text-muted",
			children: [
				"Pair an ESP32 (or ESP8266) with an HC-SR04 looking down from the lid. The board serves JSON at ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-foreground",
					children: "/status"
				}),
				". Demo mode runs here so you can use the dashboard before the hardware is online."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 flex gap-2 overflow-x-auto pb-1",
			children: tanks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => selectTank(t.id),
				className: t.id === tank.id ? "h-10 shrink-0 rounded-full bg-primary px-4 text-sm text-primary-foreground" : "h-10 shrink-0 rounded-full bg-card px-4 text-sm text-muted shadow-[var(--shadow-border)]",
				children: t.name
			}, t.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid min-w-0 gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Tank & sensor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Heights in centimetres. Offset is the gap from lid to the ultrasonic face." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: tank.name,
							onChange: (e) => save({ name: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Height (cm)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 20,
									value: tank.heightCm,
									onChange: (e) => save({ heightCm: Number(e.target.value) || tank.heightCm })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Capacity (L)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 20,
									value: tank.capacityL,
									onChange: (e) => save({ capacityL: Number(e.target.value) || tank.capacityL })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Sensor offset (cm)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									value: tank.sensorOffsetCm,
									onChange: (e) => save({ sensorOffsetCm: Number(e.target.value) || 0 })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Device ID",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: tank.deviceId,
									onChange: (e) => save({ deviceId: e.target.value })
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Low alert %",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								max: 80,
								value: tank.lowThreshold,
								onChange: (e) => save({ lowThreshold: Number(e.target.value) || 25 })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Full alert %",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 50,
								max: 100,
								value: tank.fullThreshold,
								onChange: (e) => save({ fullThreshold: Number(e.target.value) || 95 })
							})
						})]
					})
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "ESP connection" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDesc, { children: [
					"Live mode fetches ",
					statusUrl(tank.espHost),
					". Browsers block mixed HTTP from HTTPS pages — use demo here, live on the same LAN, or paste JSON below."
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-xl bg-card-2 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Live ESP polling"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-normal text-muted",
							children: "Off = animated demo sensor"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: tank.mode === "live",
						onCheckedChange: (on) => save({ mode: on ? "live" : "demo" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ESP host",
						hint: "IP or http://192.168.x.x — CORS must allow this origin.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: tank.espHost,
							onChange: (e) => save({ espHost: e.target.value }),
							placeholder: "192.168.1.50"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => {
									pollLive(tank.id);
									toast("Polling ESP…");
								},
								children: "Poll now"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => {
									const next = {
										id: uid("tank"),
										name: "New tank",
										heightCm: 150,
										capacityL: 500,
										deviceId: uid("ESP").toUpperCase(),
										espHost: "192.168.1.60",
										mode: "demo",
										lowThreshold: 25,
										fullThreshold: 95,
										sensorOffsetCm: 5
									};
									upsertTank(next);
									selectTank(next.id);
									toast("Tank added");
								},
								children: "Add tank"
							}),
							tanks.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => {
									removeTank(tank.id);
									toast("Tank removed");
								},
								children: "Remove"
							}) : null
						]
					})]
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Paste a reading" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Same JSON the firmware returns. Useful while you wait for the board, or if the browser cannot reach the LAN." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "font-mono text-xs",
					value: jsonText,
					onChange: (e) => setJsonText(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					variant: "secondary",
					onClick: () => {
						try {
							const err = applyManualJson(tank.id, JSON.parse(jsonText));
							if (err) toast(err);
							else toast("Reading applied");
						} catch {
							toast("Invalid JSON");
						}
					},
					children: "Apply JSON"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "flex-row flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "ESP32 sketch" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "TRIG GPIO 5, ECHO GPIO 18, DHT GPIO 4. Copy into Arduino IDE." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "sm",
					onClick: () => {
						navigator.clipboard.writeText(ESP32_SKETCH);
						toast("Sketch copied");
					},
					children: "Copy sketch"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "max-h-80 overflow-auto whitespace-pre-wrap break-words rounded-xl bg-background p-4 font-mono text-xs leading-relaxed text-muted",
				children: ESP32_SKETCH
			})]
		})
	] });
}
//#endregion
export { DevicePage as component };
