import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as CardTitle, i as CardHeader, n as Card, r as CardDesc, t as AppShell, v as useTankStore } from "./card-Cd-6sB1a.mjs";
import { t as Button } from "./button-DTwDogWK.mjs";
import { n as Input, r as Switch, t as Field } from "./switch-DVFrF1V-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-Cas9PAMJ.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const settings = useTankStore((s) => s.settings);
	const updateSettings = useTankStore((s) => s.updateSettings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-medium tracking-tight",
			children: "Settings"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 max-w-xl text-sm leading-normal text-muted",
			children: "Polling, alerts, and how this dashboard talks to your ultrasonic node."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Polling" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "How often demo ticks or live ESP fetches run." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Interval (seconds)",
				hint: "2–60. Live hardware can use 5–15 s to keep the sensor cool.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					min: 2,
					max: 60,
					value: settings.pollSeconds,
					onChange: (e) => updateSettings({ pollSeconds: Math.min(60, Math.max(2, Number(e.target.value) || 4)) })
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Notifications" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Browser alerts when water goes low, the tank fills, or the ESP drops." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "min-w-0 text-sm",
						children: "Enable desktop notifications"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: settings.notifications,
						onCheckedChange: (on) => {
							updateSettings({ notifications: on });
							if (on && typeof Notification !== "undefined") Notification.requestPermission().then((p) => {
								toast(p === "granted" ? "Notifications on" : "Permission denied");
							});
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "High temperature alert (°C)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 20,
							max: 80,
							value: settings.tempWarnC,
							onChange: (e) => updateSettings({ tempWarnC: Number(e.target.value) || 40 })
						})
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "How the math works" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-2 pl-5 text-sm leading-normal text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Mount HC-SR04 on the lid, facing the water." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ESP measures empty distance in cm." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Water height = tank height − distance − sensor offset." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Percent = water height ÷ usable height. Litres scale from capacity." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm leading-normal text-muted",
					children: "History is stored in this browser. AquaLevel 1.0 — ESP32 + ultrasonic."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					variant: "outline",
					onClick: () => {
						localStorage.removeItem("aqualevel-v2");
						window.location.reload();
					},
					children: "Reset demo data"
				})
			]
		})
	] });
}
//#endregion
export { SettingsPage as component };
