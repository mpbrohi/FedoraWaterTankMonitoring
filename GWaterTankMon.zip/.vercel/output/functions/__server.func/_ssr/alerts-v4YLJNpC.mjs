import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as CircleCheck, i as Thermometer, m as BatteryWarning, n as Waves, r as TriangleAlert, s as RadioTower } from "../_libs/lucide-react.mjs";
import { f as relativeTime, n as Card, s as cn, t as AppShell, v as useTankStore } from "./card-Cd-6sB1a.mjs";
import { t as Button } from "./button-DTwDogWK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/alerts-v4YLJNpC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	low_water: Waves,
	tank_full: CircleCheck,
	device_offline: RadioTower,
	sensor_fault: TriangleAlert,
	high_temp: Thermometer
};
var TONE = {
	low_water: "text-danger",
	tank_full: "text-ok",
	device_offline: "text-muted",
	sensor_fault: "text-warn",
	high_temp: "text-warn"
};
function AlertsPage() {
	const alerts = useTankStore((s) => s.alerts);
	const tanks = useTankStore((s) => s.tanks);
	const markAlertRead = useTankStore((s) => s.markAlertRead);
	const markAllRead = useTankStore((s) => s.markAllRead);
	const clearAlerts = useTankStore((s) => s.clearAlerts);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const filtered = alerts.filter((a) => {
		if (filter === "all") return true;
		if (filter === "unread") return !a.read;
		return a.type === filter;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-medium tracking-tight",
					children: "Alerts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm leading-normal text-muted",
					children: "Raised when level crosses your thresholds, the ESP goes quiet, or temperature spikes."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "sm",
					onClick: markAllRead,
					children: "Mark all read"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: clearAlerts,
					children: "Clear"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex gap-2 overflow-x-auto pb-1",
			children: [
				{
					id: "all",
					label: "All"
				},
				{
					id: "unread",
					label: "Unread"
				},
				{
					id: "low_water",
					label: "Low water"
				},
				{
					id: "tank_full",
					label: "Full"
				},
				{
					id: "device_offline",
					label: "Offline"
				}
			].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(c.id),
				className: cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium shadow-[var(--shadow-border)]", filter === c.id ? "bg-primary text-primary-foreground" : "bg-card text-muted"),
				children: c.label
			}, c.id))
		}),
		filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "No alerts in this filter."
		}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: filtered.map((a) => {
				const Icon = ICONS[a.type] ?? BatteryWarning;
				const tank = tanks.find((t) => t.id === a.tankId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => markAlertRead(a.id),
					className: cn("flex w-full min-w-0 items-start gap-3 rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)]", !a.read && "ring-1 ring-accent/40"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-md bg-card-2", TONE[a.type]),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							strokeWidth: 1.75
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 text-sm font-medium leading-snug",
								children: a.message
							}), !a.read ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 size-2 shrink-0 rounded-full bg-accent" }) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block text-xs text-muted",
							children: [
								tank?.name ?? "Tank",
								" · ",
								relativeTime(a.ts)
							]
						})]
					})]
				}) }, a.id);
			})
		})
	] });
}
//#endregion
export { AlertsPage as component };
