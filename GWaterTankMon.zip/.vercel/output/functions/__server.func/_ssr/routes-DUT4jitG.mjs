import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Gauge, i as Thermometer, n as Waves, o as Ruler, p as Beaker, t as Wifi } from "../_libs/lucide-react.mjs";
import { a as CardTitle, c as formatClock, d as rangeMs, f as relativeTime, g as tankStatus, i as CardHeader, l as formatDayTime, m as selectedTank, n as Card, p as rssiLabel, r as CardDesc, s as cn, t as AppShell, u as formatLiters, v as useTankStore } from "./card-Cd-6sB1a.mjs";
import { a as Line, c as Tooltip, i as Area, n as YAxis, o as CartesianGrid, r as XAxis, s as ResponsiveContainer, t as ComposedChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DUT4jitG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HistoryTable({ rows }) {
	const slice = rows.slice(-12).reverse();
	if (!slice.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "No readings stored yet."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-w-0 overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "text-xs uppercase tracking-wide text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 pr-3 font-medium",
						children: "Time"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 pr-3 font-medium",
						children: "Level"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 pr-3 font-medium",
						children: "Water"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 pr-3 font-medium",
						children: "Empty"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 pr-3 font-medium",
						children: "Temp"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Source"
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: slice.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "whitespace-nowrap py-2.5 pr-3 font-mono text-xs tabular-nums text-muted",
						children: formatDayTime(r.ts)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "py-2.5 pr-3 font-mono tabular-nums",
						children: [r.percent, "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "py-2.5 pr-3 font-mono tabular-nums",
						children: [r.levelCm.toFixed(1), " cm"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "py-2.5 pr-3 font-mono tabular-nums",
						children: [r.distanceCm.toFixed(1), " cm"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2.5 pr-3 font-mono tabular-nums",
						children: r.tempC == null ? "—" : `${r.tempC.toFixed(1)}°`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2.5 capitalize text-muted",
						children: r.source
					})
				]
			}, r.ts)) })]
		})
	});
}
function downsample(rows, max = 96) {
	if (rows.length <= max) return rows;
	const step = Math.ceil(rows.length / max);
	const out = [];
	for (let i = 0; i < rows.length; i += step) {
		const row = rows[i];
		if (row) out.push(row);
	}
	const last = rows[rows.length - 1];
	if (last && out[out.length - 1] !== last) out.push(last);
	return out;
}
function LevelChart({ history, range }) {
	const data = (0, import_react.useMemo)(() => {
		const from = Date.now() - rangeMs(range);
		return downsample(history.filter((r) => r.ts >= from)).map((r) => ({
			ts: r.ts,
			percent: r.percent,
			temp: r.tempC,
			liters: r.liters
		}));
	}, [history, range]);
	const tickFmt = range === "24h" ? formatClock : (ts) => formatDayTime(ts).replace(",", "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-56 w-full min-w-0 sm:h-64",
		children: data.length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-full items-center justify-center text-sm text-muted",
			children: "History will appear after the first few readings."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComposedChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "lvl",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "#5ec4bc",
							stopOpacity: .55
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "#5ec4bc",
							stopOpacity: .06
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "rgb(232 238 240 / 0.1)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "ts",
						tickFormatter: tickFmt,
						stroke: "#8b9aa2",
						tick: {
							fill: "#8b9aa2",
							fontSize: 11
						},
						tickLine: false,
						axisLine: false,
						minTickGap: 28
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						yAxisId: "lvl",
						domain: [0, 100],
						stroke: "#8b9aa2",
						tick: {
							fill: "#8b9aa2",
							fontSize: 11
						},
						tickLine: false,
						axisLine: false,
						width: 32,
						tickFormatter: (v) => `${v}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						yAxisId: "temp",
						orientation: "right",
						domain: [15, 40],
						stroke: "#8b9aa2",
						tick: {
							fill: "#8b9aa2",
							fontSize: 11
						},
						tickLine: false,
						axisLine: false,
						width: 36,
						tickFormatter: (v) => `${v}°`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						contentStyle: {
							background: "#12181c",
							border: "1px solid rgb(232 238 240 / 0.1)",
							borderRadius: 12,
							fontSize: 12,
							color: "#e8eef0"
						},
						labelFormatter: (v) => formatDayTime(Number(v)),
						formatter: (value, name) => {
							const n = typeof value === "number" ? value : Number(value);
							if (name === "percent") return [`${n}%`, "Level"];
							if (name === "temp") return [`${n}°C`, "Temp"];
							return [String(value ?? ""), String(name)];
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						yAxisId: "lvl",
						type: "monotone",
						dataKey: "percent",
						stroke: "#5ec4bc",
						strokeWidth: 2.5,
						fill: "url(#lvl)",
						dot: false,
						isAnimationActive: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						yAxisId: "temp",
						type: "monotone",
						dataKey: "temp",
						stroke: "#e0a36a",
						strokeWidth: 2,
						dot: false,
						isAnimationActive: false
					})
				]
			})
		})
	});
}
function StatTile({ icon: Icon, label, value, hint, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex min-w-0 items-start gap-3 rounded-xl bg-card-2 p-4 shadow-[var(--shadow-border)]", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md bg-background text-accent",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-4",
				strokeWidth: 1.75
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-wide text-muted",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 break-words font-mono text-lg font-medium tabular-nums leading-snug text-foreground",
					children: value
				}),
				hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs leading-normal text-muted",
					children: hint
				}) : null
			]
		})]
	});
}
function Badge({ className, tone = "neutral", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex max-w-full items-center rounded-full px-2.5 py-1 text-xs font-medium leading-none", {
			neutral: "bg-card-2 text-muted",
			ok: "bg-ok/15 text-ok",
			warn: "bg-warn/15 text-warn",
			danger: "bg-danger/15 text-danger",
			accent: "bg-accent/15 text-accent"
		}[tone], className),
		children
	});
}
var MAP = {
	normal: {
		label: "Normal",
		tone: "ok"
	},
	low: {
		label: "Low water",
		tone: "danger"
	},
	full: {
		label: "Full",
		tone: "accent"
	},
	offline: {
		label: "Offline",
		tone: "neutral"
	},
	fault: {
		label: "Sensor fault",
		tone: "warn"
	}
};
function StatusPill({ status }) {
	const m = MAP[status];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: m.tone,
		children: m.label
	});
}
var INNER_TOP = 62;
var INNER_BOTTOM = 348;
var INNER_HEIGHT = 286;
function waterColor(status, percent) {
	if (status === "offline" || status === "fault") return {
		fill: "#4a5560",
		deep: "#2a3238"
	};
	if (percent <= 20 || status === "low") return {
		fill: "#c45c52",
		deep: "#7a2e2a"
	};
	if (percent >= 90 || status === "full") return {
		fill: "#3d9b8f",
		deep: "#1a5f6b"
	};
	return {
		fill: "#2a8f9e",
		deep: "#164e58"
	};
}
function TankVisual({ percent, levelCm, heightCm, status, className }) {
	const p = Math.max(0, Math.min(100, percent));
	const shift = (100 - p) / 100 * INNER_HEIGHT;
	const { fill, deep } = waterColor(status, p);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative mx-auto w-full max-w-52 select-none sm:max-w-xs", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 280 420",
			className: "h-auto w-full overflow-visible",
			role: "img",
			"aria-label": `Tank at ${Math.round(p)} percent, ${levelCm} centimetres of ${heightCm}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "shell",
						x1: "0",
						x2: "1",
						y1: "0",
						y2: "0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "0%",
								stopColor: "#1a2228"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "35%",
								stopColor: "#2a343c"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "65%",
								stopColor: "#232c32"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "100%",
								stopColor: "#151c21"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "water",
						x1: "0",
						x2: "0",
						y1: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: fill,
							stopOpacity: "0.92"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: deep,
							stopOpacity: "1"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "shine",
						x1: "0",
						x2: "1",
						y1: "0",
						y2: "0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "0%",
								stopColor: "#fff",
								stopOpacity: "0"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "22%",
								stopColor: "#fff",
								stopOpacity: "0.1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "40%",
								stopColor: "#fff",
								stopOpacity: "0"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("clipPath", {
						id: "tank-inner",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "58",
							y: INNER_TOP,
							width: "132",
							height: INNER_HEIGHT,
							rx: "8"
						})
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "124",
					cy: "392",
					rx: "78",
					ry: "10",
					fill: "#000",
					opacity: "0.35"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "188",
					y: "328",
					width: "28",
					height: "10",
					rx: "3",
					fill: "#1c242a"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "212",
					y: "322",
					width: "10",
					height: "22",
					rx: "3",
					fill: "#243038"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "50",
					y: "54",
					width: "148",
					height: "304",
					rx: "18",
					fill: "url(#shell)",
					stroke: "#3a464e",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "56",
					y: "60",
					width: "136",
					height: "292",
					rx: "14",
					fill: "#0d1317",
					stroke: "#2a343c",
					strokeWidth: "1"
				}),
				[
					110,
					190,
					270
				].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "48",
					y,
					width: "152",
					height: "6",
					rx: "2",
					fill: "#1c262c",
					opacity: "0.9"
				}, y)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
					clipPath: "url(#tank-inner)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						className: "tank-water",
						style: {
							transform: `translateY(${shift}px)`,
							transition: "transform 900ms cubic-bezier(0.22, 1, 0.36, 1)"
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: "58",
								y: 42,
								width: "132",
								height: 326,
								fill: "url(#water)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
								className: "wave-a",
								style: { transformOrigin: "58px 0" },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M28 70 C 50 58, 72 82, 94 70 S 138 58, 160 70 S 204 82, 226 70 V 90 H 28 Z",
									fill,
									opacity: "0.85"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
								className: "wave-b",
								style: { transformOrigin: "58px 0" },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M28 76 C 54 88, 78 64, 104 76 S 150 88, 176 76 S 214 64, 236 76 V 96 H 28 Z",
									fill: "#d7f4f2",
									opacity: "0.18"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								className: "bubble",
								cx: "88",
								cy: "280",
								r: "3",
								fill: "#fff",
								opacity: "0.35"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								className: "bubble",
								cx: "142",
								cy: "250",
								r: "2.2",
								fill: "#fff",
								opacity: "0.3",
								style: {
									animationDelay: "1.4s",
									animationDuration: "6.4s"
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								className: "bubble",
								cx: "118",
								cy: "310",
								r: "2.6",
								fill: "#fff",
								opacity: "0.28",
								style: {
									animationDelay: "2.6s",
									animationDuration: "7s"
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: "58",
								y: 42,
								width: "132",
								height: 326,
								fill: "url(#shine)"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "64",
					y: "72",
					width: "10",
					height: "250",
					rx: "5",
					fill: "#fff",
					opacity: "0.05"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "44",
					y: "40",
					width: "160",
					height: "18",
					rx: "6",
					fill: "#2a343c",
					stroke: "#445058",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "96",
					y: "18",
					width: "56",
					height: "26",
					rx: "6",
					fill: "#1a2228",
					stroke: "#3a464e",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "112",
					cy: "31",
					r: "5",
					fill: "#0d1317",
					stroke: "#2f8f86",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "136",
					cy: "31",
					r: "5",
					fill: "#0d1317",
					stroke: "#2f8f86",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "124",
					y1: "18",
					x2: "124",
					y2: "10",
					stroke: "#3a464e",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "124",
					cy: "8",
					r: "3",
					fill: "#2f8f86"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "204",
					y: "70",
					width: "16",
					height: "270",
					rx: "6",
					fill: "#0d1317",
					stroke: "#3a464e",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "206",
					y: 70 + (100 - p) / 100 * 266,
					width: "12",
					height: p / 100 * 266,
					rx: "4",
					fill,
					style: { transition: "y 900ms cubic-bezier(0.22, 1, 0.36, 1), height 900ms cubic-bezier(0.22, 1, 0.36, 1)" }
				}),
				[
					0,
					25,
					50,
					75,
					100
				].map((t) => {
					const y = INNER_BOTTOM - t / 100 * INNER_HEIGHT;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "222",
						y1: y,
						x2: "232",
						y2: y,
						stroke: "#8b9aa2",
						strokeWidth: "1"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "236",
						y: y + 4,
						fill: "#8b9aa2",
						fontSize: "11",
						fontFamily: "IBM Plex Mono, ui-monospace, monospace",
						children: t
					})] }, t);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: `200,${INNER_BOTTOM - p / 100 * INNER_HEIGHT} 208,${INNER_BOTTOM - p / 100 * INNER_HEIGHT - 5} 208,${INNER_BOTTOM - p / 100 * INNER_HEIGHT + 5}`,
					fill: "#e8eef0",
					style: { transition: "all 900ms cubic-bezier(0.22, 1, 0.36, 1)" }
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-x-0 top-1/2 flex -translate-y-8 flex-col items-center px-8 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-3xl font-medium tabular-nums tracking-tight text-foreground drop-shadow-[0_2px_12px_rgba(0,0,0,0.65)] sm:text-4xl",
				children: [Math.round(p), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xl text-muted",
					children: "%"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 max-w-full font-mono text-sm tabular-nums text-muted",
				children: [
					levelCm.toFixed(1),
					" / ",
					heightCm,
					" cm"
				]
			})]
		})]
	});
}
function TempGauge({ tempC, humidity, className }) {
	const t = tempC ?? 0;
	const ratio = tempC == null ? 0 : Math.min(1, Math.max(0, (t - 10) / 35));
	const r = 42;
	const c = 2 * Math.PI * r;
	const dash = c * .75;
	const offset = dash * (1 - ratio);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex min-w-0 items-center gap-4", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 120 120",
			className: "size-24 shrink-0",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					transform: "rotate(135 60 60)",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r,
						fill: "none",
						stroke: "#1c262c",
						strokeWidth: "8",
						strokeDasharray: `${dash} ${c}`,
						strokeLinecap: "round"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r,
						fill: "none",
						stroke: "#2f8f86",
						strokeWidth: "8",
						strokeDasharray: `${dash} ${c}`,
						strokeDashoffset: offset,
						strokeLinecap: "round",
						style: { transition: "stroke-dashoffset 700ms cubic-bezier(0.22, 1, 0.36, 1)" }
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "60",
					y: "58",
					textAnchor: "middle",
					fill: "#e8eef0",
					fontSize: "22",
					fontFamily: "IBM Plex Mono, ui-monospace, monospace",
					fontWeight: "500",
					children: tempC == null ? "—" : t.toFixed(1)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "60",
					y: "76",
					textAnchor: "middle",
					fill: "#8b9aa2",
					fontSize: "11",
					fontFamily: "Outfit, sans-serif",
					children: "°C"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-foreground",
				children: "Temperature"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm leading-normal text-muted",
				children: ["DHT / DS18B20 on the ESP. ", humidity == null ? "Humidity unavailable." : `Humidity ${humidity.toFixed(0)}%.`]
			})]
		})]
	});
}
var RANGES = [
	"24h",
	"7d",
	"30d"
];
function Home() {
	const hydrated = useTankStore((s) => s.hydrated);
	const tanks = useTankStore((s) => s.tanks);
	const selectedId = useTankStore((s) => s.selectedId);
	const selectTank = useTankStore((s) => s.selectTank);
	const latest = useTankStore((s) => s.latest);
	const history = useTankStore((s) => s.history);
	const pollError = useTankStore((s) => s.pollError);
	const [range, setRange] = (0, import_react.useState)("24h");
	const tank = selectedTank({
		tanks,
		selectedId
	});
	const reading = tank ? latest[tank.id] : void 0;
	const series = tank ? history[tank.id] ?? [] : [];
	const status = tank ? tankStatus(tank, reading) : "offline";
	const windowed = series.filter((r) => r.ts >= Date.now() - rangeMs(range));
	const firstL = windowed[0]?.liters ?? 0;
	const lastL = windowed[windowed.length - 1]?.liters ?? 0;
	const used = windowed.length >= 2 ? Math.max(0, firstL - lastL) : 0;
	if (!hydrated || !tank) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 sm:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-80 animate-pulse rounded-2xl bg-card" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-80 animate-pulse rounded-2xl bg-card" })]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex min-w-0 flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted",
						children: "Live monitor"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-medium tracking-tight sm:text-3xl",
						children: tank.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-xl text-sm leading-normal text-muted",
						children: "HC-SR04 measures empty space from the lid. Level = tank height − distance − sensor offset."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					tone: tank.mode === "live" ? "accent" : "neutral",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mr-1.5 inline-block size-1.5 rounded-full bg-current", tank.mode === "demo" || reading?.online ? "live-dot" : "") }), tank.mode === "demo" ? "Demo sensor" : reading?.online ? "ESP live" : "ESP down"]
				})]
			})]
		}),
		tanks.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6 flex min-w-0 gap-2 overflow-x-auto pb-1",
			children: tanks.map((t) => {
				const r = latest[t.id];
				const active = t.id === tank.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => selectTank(t.id),
					className: cn("min-w-40 shrink-0 rounded-xl px-4 py-3 text-left shadow-[var(--shadow-border)] transition-colors duration-150", active ? "bg-card-2" : "bg-card hover:bg-card-2"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium",
						children: t.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-lg tabular-nums",
						children: [r?.percent ?? "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: " %"
						})]
					})]
				}, t.id);
			})
		}) : null,
		pollError[tank.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-4 rounded-xl bg-danger/10 px-4 py-3 text-sm leading-normal text-danger",
			children: [pollError[tank.id], ". The app keeps the last reading. Check ESP IP, CORS, and that the sketch serves GET /status."]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid min-w-0 gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col items-center p-4 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TankVisual, {
					percent: reading?.percent ?? 0,
					levelCm: reading?.levelCm ?? 0,
					heightCm: tank.heightCm,
					status
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xs text-center text-xs leading-normal text-muted",
					children: "Sight glass on the right is the level indicator. Waves follow live fill."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TempGauge, {
					tempC: reading?.tempC ?? null,
					humidity: reading?.humidity ?? null
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							icon: Beaker,
							label: "Volume",
							value: formatLiters(reading?.liters ?? 0),
							hint: `of ${formatLiters(tank.capacityL)} capacity`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							icon: Ruler,
							label: "Empty distance",
							value: `${(reading?.distanceCm ?? 0).toFixed(1)} cm`,
							hint: "Ultrasonic echo to water"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							icon: Waves,
							label: "Water column",
							value: `${(reading?.levelCm ?? 0).toFixed(1)} cm`,
							hint: `Offset ${tank.sensorOffsetCm} cm`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							icon: Wifi,
							label: "Wi-Fi",
							value: rssiLabel(reading?.rssi ?? null),
							hint: reading?.rssi != null ? `${reading.rssi} dBm` : "No RSSI yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							icon: Gauge,
							label: "Updated",
							value: reading ? relativeTime(reading.ts) : "—",
							hint: tank.deviceId
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							icon: Thermometer,
							label: "Humidity",
							value: reading?.humidity == null ? "—" : `${reading.humidity.toFixed(0)}%`,
							hint: "From DHT on ESP"
						})
					]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "mb-2 flex-row flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Level & temperature" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Teal fill is water level. Amber line is temperature from the ESP." })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex rounded-full bg-card-2 p-1 shadow-[var(--shadow-border)]",
						children: RANGES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setRange(r),
							className: cn("h-9 min-w-14 rounded-full px-3 text-xs font-medium", range === r ? "bg-primary text-primary-foreground" : "text-muted"),
							children: r
						}, r))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelChart, {
					history: series,
					range
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-muted",
					children: [
						range,
						" change ",
						used > 0 ? `≈ ${formatLiters(used)} used` : "is a net fill or steady",
						"."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Recent readings" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Stored on this device. Live polls append here automatically." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryTable, { rows: series })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-3 sm:grid-cols-3",
			children: tanks.map((t) => {
				const r = latest[t.id];
				const st = tankStatus(t, r);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => selectTank(t.id),
					className: "rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "min-w-0 truncate font-medium",
								children: t.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: st })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1.5 overflow-hidden rounded-full bg-card-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("h-full rounded-full transition-[width] duration-700", st === "low" ? "bg-danger" : st === "full" ? "bg-accent" : "bg-water"),
								style: { width: `${r?.percent ?? 0}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 font-mono text-sm tabular-nums text-muted",
							children: [
								r?.percent ?? 0,
								"% · ",
								formatLiters(r?.liters ?? 0),
								r?.tempC != null ? ` · ${r.tempC.toFixed(1)}°C` : ""
							]
						})
					]
				}, t.id);
			})
		})
	] });
}
//#endregion
export { Home as component };
