import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as useRouterState, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Settings, f as Bell, h as Activity, l as Droplets, u as Cpu } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/card-Cd-6sB1a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function round1(n) {
	return Math.round(n * 10) / 10;
}
function formatLiters(n) {
	if (n >= 1e3) return `${(n / 1e3).toFixed(n >= 1e4 ? 0 : 1)}k L`;
	return `${Math.round(n)} L`;
}
function relativeTime(ts, now = Date.now()) {
	const s = Math.max(0, Math.round((now - ts) / 1e3));
	if (s < 10) return "just now";
	if (s < 60) return `${s}s ago`;
	const m = Math.round(s / 60);
	if (m < 60) return `${m}m ago`;
	const h = Math.round(m / 60);
	if (h < 24) return `${h}h ago`;
	return `${Math.round(h / 24)}d ago`;
}
function formatClock(ts) {
	return new Date(ts).toLocaleTimeString([], {
		hour: "2-digit",
		minute: "2-digit"
	});
}
function formatDayTime(ts) {
	return new Date(ts).toLocaleString([], {
		month: "short",
		day: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function rssiLabel(rssi) {
	if (rssi == null) return "—";
	if (rssi >= -50) return "Excellent";
	if (rssi >= -60) return "Good";
	if (rssi >= -70) return "Fair";
	return "Weak";
}
function num(v) {
	if (typeof v === "number" && Number.isFinite(v)) return v;
	if (typeof v === "string" && v.trim() !== "") {
		const n = Number(v);
		if (Number.isFinite(n)) return n;
	}
	return null;
}
function pick(obj, keys) {
	for (const k of keys) if (k in obj) {
		const n = num(obj[k]);
		if (n != null) return n;
	}
	return null;
}
function parseEspPayload(raw) {
	if (!raw || typeof raw !== "object") return null;
	const obj = raw;
	const nested = obj.data && typeof obj.data === "object" ? obj.data : obj;
	const distanceCm = pick(nested, [
		"distance_cm",
		"distanceCm",
		"distance",
		"dist",
		"empty_cm",
		"emptyCm",
		"cm"
	]);
	if (distanceCm == null) return null;
	return {
		distanceCm,
		tempC: pick(nested, [
			"temperature_c",
			"temperatureC",
			"temperature",
			"tempC",
			"temp"
		]),
		humidity: pick(nested, [
			"humidity",
			"hum",
			"rh"
		]),
		rssi: pick(nested, [
			"rssi",
			"wifi",
			"signal",
			"wifi_rssi"
		])
	};
}
function readingFromDistance(tank, payload, source, ts = Date.now()) {
	const usableHeight = Math.max(1, tank.heightCm - tank.sensorOffsetCm);
	const levelCm = round1(usableHeight - clamp(payload.distanceCm - tank.sensorOffsetCm, 0, usableHeight));
	const percent = clamp(Math.round(levelCm / usableHeight * 100), 0, 100);
	const liters = Math.round(percent / 100 * tank.capacityL);
	return {
		ts,
		distanceCm: round1(payload.distanceCm),
		levelCm,
		percent,
		liters,
		tempC: payload.tempC != null ? round1(payload.tempC) : null,
		humidity: payload.humidity != null ? round1(payload.humidity) : null,
		rssi: payload.rssi != null ? Math.round(payload.rssi) : null,
		online: true,
		source
	};
}
function statusUrl(host) {
	const trimmed = host.trim().replace(/\/$/, "");
	if (/^https?:\/\//i.test(trimmed)) return trimmed.endsWith("/status") ? trimmed : `${trimmed}/status`;
	return `http://${trimmed}/status`;
}
async function fetchEsp(host, timeoutMs = 4e3) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), timeoutMs);
	try {
		const res = await fetch(statusUrl(host), {
			signal: ctrl.signal,
			cache: "no-store",
			headers: { Accept: "application/json" }
		});
		if (!res.ok) throw new Error(`ESP HTTP ${res.status}`);
		const parsed = parseEspPayload(await res.json());
		if (!parsed) throw new Error("ESP JSON missing distance");
		return parsed;
	} finally {
		clearTimeout(timer);
	}
}
var ESP32_SKETCH = `/*
  AquaLevel — ESP32 + HC-SR04 ultrasonic + DHT11/DHT22
  Arduino IDE: install "DHT sensor library" by Adafruit.

  Wiring
    HC-SR04 TRIG -> GPIO 5
    HC-SR04 ECHO -> GPIO 18   (use a 1k/2k divider if the module is 5V)
    DHT DATA     -> GPIO 4    (optional — temp/humidity)
    VCC 3.3V or 5V as the module requires, GND common
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>

const char* WIFI_SSID = "YOUR_WIFI";
const char* WIFI_PASS = "YOUR_PASSWORD";

const int PIN_TRIG = 5;
const int PIN_ECHO = 18;
const int PIN_DHT  = 4;
#define DHTTYPE DHT11

WebServer server(80);
DHT dht(PIN_DHT, DHTTYPE);

float readDistanceCm() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(4);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  unsigned long us = pulseIn(PIN_ECHO, HIGH, 30000UL);
  if (us == 0) return -1;
  return (us * 0.0343f) / 2.0f;
}

void sendCors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "*");
}

void handleStatus() {
  sendCors();
  float dist = readDistanceCm();
  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();

  String json = "{";
  json += "\\"ok\\":true,";
  json += "\\"distance_cm\\":" + String(dist, 1) + ",";
  if (isnan(temp)) json += "\\"temperature_c\\":null,";
  else             json += "\\"temperature_c\\":" + String(temp, 1) + ",";
  if (isnan(hum))  json += "\\"humidity\\":null,";
  else             json += "\\"humidity\\":" + String(hum, 1) + ",";
  json += "\\"rssi\\":" + String(WiFi.RSSI()) + ",";
  json += "\\"ip\\":\\"" + WiFi.localIP().toString() + "\\",";
  json += "\\"uptime_s\\":" + String(millis() / 1000) + ",";
  json += "\\"firmware\\":\\"aqualevel-1.0\\"";
  json += "}";
  server.send(200, "application/json", json);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  dht.begin();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) delay(400);

  server.on("/status", HTTP_GET, handleStatus);
  server.on("/status", HTTP_OPTIONS, []() {
    sendCors();
    server.send(204);
  });
  server.on("/", []() {
    sendCors();
    server.send(200, "text/plain", "AquaLevel ESP ready. GET /status");
  });
  server.begin();
  Serial.print("AquaLevel http://");
  Serial.print(WiFi.localIP());
  Serial.println("/status");
}

void loop() {
  server.handleClient();
}
`;
var STORAGE_KEY = "aqualevel-v2";
function defaultTanks() {
	return [{
		id: "tank-roof",
		name: "Roof Tank",
		heightCm: 180,
		capacityL: 1e3,
		deviceId: "ESP-ROOF-01",
		espHost: "192.168.1.50",
		mode: "demo",
		lowThreshold: 25,
		fullThreshold: 95,
		sensorOffsetCm: 5
	}, {
		id: "tank-ground",
		name: "Ground Tank",
		heightCm: 200,
		capacityL: 2e3,
		deviceId: "ESP-GND-01",
		espHost: "192.168.1.51",
		mode: "demo",
		lowThreshold: 20,
		fullThreshold: 95,
		sensorOffsetCm: 8
	}];
}
function seedHistory(tank, now) {
	const out = [];
	let percent = tank.id.includes("ground") ? 48 : 72;
	let temp = tank.id.includes("ground") ? 26.1 : 29.4;
	let hum = 58;
	const end = now;
	let ts = now - 2592e6;
	while (ts <= end) {
		const ageMs = end - ts;
		const step = ageMs > 6048e5 ? 108e5 : ageMs > 864e5 ? 36e5 : 9e5;
		const hourScale = step / 36e5;
		const hour = new Date(ts).getHours();
		if (hour >= 6 && hour <= 9) percent -= (.55 + Math.random() * .7) * hourScale;
		else if (hour >= 18 && hour <= 21) percent -= (.45 + Math.random() * .55) * hourScale;
		else if (hour >= 11 && hour <= 13) percent += (1.1 + Math.random() * 1.2) * hourScale;
		else percent += (Math.random() - .48) * .25 * hourScale;
		percent = clamp(percent, 14, 97);
		temp += (Math.random() - .5) * .22 * Math.min(hourScale, 2);
		temp = clamp(temp, 22, 36);
		hum += (Math.random() - .5) * .8 * Math.min(hourScale, 2);
		hum = clamp(hum, 35, 82);
		const usable = tank.heightCm - tank.sensorOffsetCm;
		const levelCm = percent / 100 * usable;
		const distanceCm = tank.sensorOffsetCm + (usable - levelCm);
		out.push({
			ts,
			distanceCm: round1(distanceCm),
			levelCm: round1(levelCm),
			percent: Math.round(percent),
			liters: Math.round(percent / 100 * tank.capacityL),
			tempC: round1(temp),
			humidity: round1(hum),
			rssi: -48 - Math.round(Math.random() * 16),
			online: true,
			source: "demo"
		});
		ts += step;
	}
	return out;
}
function seedAlerts(tanks, now) {
	const roof = tanks[0];
	const ground = tanks[1];
	if (!roof || !ground) return [];
	return [
		{
			id: "a1",
			tankId: ground.id,
			type: "low_water",
			message: `${ground.name} dropped below ${ground.lowThreshold}% during evening use`,
			ts: now - 108e5,
			read: false
		},
		{
			id: "a2",
			tankId: roof.id,
			type: "tank_full",
			message: `${roof.name} reached full after the noon motor run`,
			ts: now - 1008e5,
			read: true
		},
		{
			id: "a3",
			tankId: roof.id,
			type: "device_offline",
			message: `${roof.name} ESP missed two poll cycles`,
			ts: now - 1872e5,
			read: true
		}
	];
}
function tankStatus(tank, reading) {
	if (!reading || !reading.online) return "offline";
	if (reading.distanceCm < 0) return "fault";
	if (reading.percent >= tank.fullThreshold) return "full";
	if (reading.percent <= tank.lowThreshold) return "low";
	return "normal";
}
function rangeMs(range) {
	if (range === "24h") return 864e5;
	if (range === "7d") return 6048e5;
	return 2592e6;
}
var defaultSettings = {
	pollSeconds: 4,
	notifications: false,
	tempWarnC: 40
};
function persist(s) {
	if (typeof window === "undefined") return;
	const payload = {
		tanks: s.tanks,
		selectedId: s.selectedId,
		history: s.history,
		latest: s.latest,
		alerts: s.alerts.slice(0, 80),
		settings: s.settings
	};
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
	} catch {}
}
function load() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function fresh() {
	const tanks = defaultTanks();
	const now = Date.now();
	const history = {};
	const latest = {};
	for (const tank of tanks) {
		const series = seedHistory(tank, now);
		history[tank.id] = series;
		const last = series[series.length - 1];
		if (last) latest[tank.id] = last;
	}
	return {
		tanks,
		selectedId: tanks[0]?.id ?? "",
		history,
		latest,
		alerts: seedAlerts(tanks, now),
		settings: defaultSettings
	};
}
function pushHistory(history, tankId, reading) {
	const prev = history[tankId] ?? [];
	const last = prev[prev.length - 1];
	if (last && reading.ts - last.ts < 8e3) return {
		...history,
		[tankId]: [...prev.slice(0, -1), reading]
	};
	const next = [...prev, reading];
	const cutoff = Date.now() - 27648e5;
	const trimmed = next.filter((r) => r.ts >= cutoff).slice(-1400);
	return {
		...history,
		[tankId]: trimmed
	};
}
function maybeAlerts(tank, reading, prev, settings) {
	const out = [];
	const add = (type, message) => {
		out.push({
			id: uid("al"),
			tankId: tank.id,
			type,
			message,
			ts: reading.ts,
			read: false
		});
	};
	const crossed = (key) => !prev || key(prev) !== key(reading);
	if (!reading.online && (!prev || prev.online)) add("device_offline", `${tank.name} ESP is unreachable`);
	if (reading.online && reading.percent <= tank.lowThreshold && crossed((r) => r.percent <= tank.lowThreshold && r.online)) add("low_water", `${tank.name} is at ${reading.percent}% (${reading.levelCm} cm)`);
	if (reading.online && reading.percent >= tank.fullThreshold && crossed((r) => r.percent >= tank.fullThreshold && r.online)) add("tank_full", `${tank.name} is full (${reading.percent}%)`);
	if (reading.distanceCm < 0) add("sensor_fault", `${tank.name} ultrasonic echo timed out`);
	if (reading.tempC != null && reading.tempC >= settings.tempWarnC && (!prev || prev.tempC == null || prev.tempC < settings.tempWarnC)) add("high_temp", `${tank.name} sensor reads ${reading.tempC}°C`);
	return out;
}
var useTankStore = create((set, get) => ({
	...fresh(),
	hydrated: false,
	pollError: {},
	hydrate: () => {
		const saved = load();
		if (saved?.tanks?.length) set({
			...saved,
			settings: {
				...defaultSettings,
				...saved.settings
			},
			hydrated: true,
			pollError: {}
		});
		else {
			const next = fresh();
			persist(next);
			set({
				...next,
				hydrated: true,
				pollError: {}
			});
		}
	},
	selectTank: (id) => {
		set({ selectedId: id });
		persist(get());
	},
	upsertTank: (tank) => {
		const { tanks, history, latest, selectedId } = get();
		const nextTanks = tanks.some((t) => t.id === tank.id) ? tanks.map((t) => t.id === tank.id ? tank : t) : [...tanks, tank];
		const nextHistory = history[tank.id] ? history : {
			...history,
			[tank.id]: seedHistory(tank, Date.now())
		};
		const last = nextHistory[tank.id]?.at(-1);
		set({
			tanks: nextTanks,
			history: nextHistory,
			latest: latest[tank.id] ? latest : last ? {
				...latest,
				[tank.id]: last
			} : latest,
			selectedId: selectedId || tank.id
		});
		persist(get());
	},
	removeTank: (id) => {
		const { tanks, history, latest, alerts, selectedId } = get();
		const nextTanks = tanks.filter((t) => t.id !== id);
		const { [id]: _h, ...restH } = history;
		const { [id]: _l, ...restL } = latest;
		set({
			tanks: nextTanks,
			history: restH,
			latest: restL,
			alerts: alerts.filter((a) => a.tankId !== id),
			selectedId: selectedId === id ? nextTanks[0]?.id ?? "" : selectedId
		});
		persist(get());
	},
	updateSettings: (patch) => {
		set({ settings: {
			...get().settings,
			...patch
		} });
		persist(get());
	},
	markAlertRead: (id) => {
		set({ alerts: get().alerts.map((a) => a.id === id ? {
			...a,
			read: true
		} : a) });
		persist(get());
	},
	markAllRead: () => {
		set({ alerts: get().alerts.map((a) => ({
			...a,
			read: true
		})) });
		persist(get());
	},
	clearAlerts: () => {
		set({ alerts: [] });
		persist(get());
	},
	ingest: (tankId, reading, error = null) => {
		const { tanks, history, latest, alerts, settings, pollError } = get();
		const tank = tanks.find((t) => t.id === tankId);
		if (!tank) return;
		const prev = latest[tankId];
		const extra = maybeAlerts(tank, reading, prev, settings);
		set({
			history: pushHistory(history, tankId, reading),
			latest: {
				...latest,
				[tankId]: reading
			},
			alerts: [...extra, ...alerts].slice(0, 80),
			pollError: {
				...pollError,
				[tankId]: error
			}
		});
		persist(get());
		if (settings.notifications && extra.length && typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") {
			const first = extra[0];
			if (first) new Notification("AquaLevel", { body: first.message });
		}
	},
	applyManualJson: (tankId, raw) => {
		const tank = get().tanks.find((t) => t.id === tankId);
		if (!tank) return "Tank not found";
		const parsed = parseEspPayload(raw);
		if (!parsed) return "JSON must include distance_cm (or distance)";
		get().ingest(tankId, readingFromDistance(tank, parsed, "manual"));
		return null;
	},
	tickDemo: (tankId) => {
		const { tanks, latest } = get();
		const tank = tanks.find((t) => t.id === tankId);
		if (!tank || tank.mode !== "demo") return;
		const prev = latest[tankId];
		const usable = tank.heightCm - tank.sensorOffsetCm;
		let percent = prev?.percent ?? 60;
		percent = clamp(percent + (Math.random() - .46) * 1.15, 8, 98);
		const levelCm = percent / 100 * usable;
		const distanceCm = tank.sensorOffsetCm + (usable - levelCm);
		let temp = prev?.tempC ?? 27;
		temp = clamp(temp + (Math.random() - .5) * .18, 22, 36);
		let hum = prev?.humidity ?? 55;
		hum = clamp(hum + (Math.random() - .5) * .6, 30, 85);
		get().ingest(tankId, {
			ts: Date.now(),
			distanceCm: round1(distanceCm),
			levelCm: round1(levelCm),
			percent: Math.round(percent),
			liters: Math.round(percent / 100 * tank.capacityL),
			tempC: round1(temp),
			humidity: round1(hum),
			rssi: prev?.rssi ?? -55,
			online: true,
			source: "demo"
		});
	},
	pollLive: async (tankId) => {
		const tank = get().tanks.find((t) => t.id === tankId);
		if (!tank || tank.mode !== "live") return;
		const prev = get().latest[tankId];
		try {
			const payload = await fetchEsp(tank.espHost);
			get().ingest(tankId, readingFromDistance(tank, payload, "esp"));
		} catch (err) {
			const message = err instanceof Error ? err.message : "ESP unreachable";
			const offline = prev ? {
				...prev,
				ts: Date.now(),
				online: false,
				source: "esp"
			} : {
				ts: Date.now(),
				distanceCm: 0,
				levelCm: 0,
				percent: 0,
				liters: 0,
				tempC: null,
				humidity: null,
				rssi: null,
				online: false,
				source: "esp"
			};
			get().ingest(tankId, offline, message);
		}
	}
}));
function selectedTank(s) {
	return s.tanks.find((t) => t.id === s.selectedId) ?? s.tanks[0];
}
var NAV = [
	{
		to: "/",
		label: "Monitor",
		icon: Activity
	},
	{
		to: "/alerts",
		label: "Alerts",
		icon: Bell
	},
	{
		to: "/device",
		label: "Device",
		icon: Cpu
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const hydrate = useTankStore((s) => s.hydrate);
	const hydrated = useTankStore((s) => s.hydrated);
	const tanks = useTankStore((s) => s.tanks);
	const settings = useTankStore((s) => s.settings);
	const tickDemo = useTankStore((s) => s.tickDemo);
	const pollLive = useTankStore((s) => s.pollLive);
	const unread = useTankStore((s) => s.alerts.filter((a) => !a.read).length);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const tick = () => {
			for (const t of useTankStore.getState().tanks) if (t.mode === "demo") tickDemo(t.id);
			else pollLive(t.id);
		};
		tick();
		const id = window.setInterval(tick, Math.max(2, settings.pollSeconds) * 1e3);
		return () => window.clearInterval(id);
	}, [
		hydrated,
		settings.pollSeconds,
		tickDemo,
		pollLive,
		tanks.length
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-border bg-background/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex min-w-0 items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-9 shrink-0 items-center justify-center rounded-md bg-card-2 text-accent shadow-[var(--shadow-border)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, {
								className: "size-4",
								strokeWidth: 1.75
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-medium leading-tight",
								children: "AquaLevel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-muted",
								children: "ESP + ultrasonic"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "ml-auto hidden items-center gap-1 md:flex",
						children: NAV.map((item) => {
							const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("relative flex h-11 items-center gap-2 rounded-md px-3 text-sm transition-colors duration-150", active ? "bg-card-2 text-foreground" : "text-muted hover:text-foreground"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-4 shrink-0",
										strokeWidth: 1.75
									}),
									item.label,
									item.to === "/alerts" && unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-danger px-1.5 py-0.5 font-mono text-xs text-foreground",
										children: unread
									}) : null
								]
							}, item.to);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-6xl px-4 pb-28 pt-6 md:pb-12",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-4",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("relative flex min-h-14 flex-col items-center justify-center gap-1 px-1 text-xs leading-none", active ? "text-foreground" : "text-muted"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									strokeWidth: 1.75
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "max-w-full truncate",
									children: item.label
								}),
								item.to === "/alerts" && unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-1/4 top-2 size-1.5 rounded-full bg-danger" }) : null
							]
						}) }, item.to);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				richColors: false
			})
		]
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("min-w-0 rounded-2xl bg-card p-5 text-foreground shadow-[var(--shadow-border)]", className),
		...props
	});
}
function CardHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 flex min-w-0 flex-col gap-1", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: cn("text-base font-medium leading-snug tracking-tight", className),
		...props
	});
}
function CardDesc({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-sm leading-normal text-muted", className),
		...props
	});
}
//#endregion
export { uid as _, CardTitle as a, formatClock as c, rangeMs as d, relativeTime as f, tankStatus as g, statusUrl as h, CardHeader as i, formatDayTime as l, selectedTank as m, Card as n, ESP32_SKETCH as o, rssiLabel as p, CardDesc as r, cn as s, AppShell as t, formatLiters as u, useTankStore as v };
