//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ByHfpREa.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/alerts",
			"/device",
			"/settings"
		],
		preloads: ["/assets/index-Dwff9h5M.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dwff9h5M.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bqte8H8l.js",
			"/assets/card-Zhmq5vvW.js",
			"/assets/waves-YyUgmF0E.js"
		]
	},
	"/alerts": {
		filePath: "/workspace/src/routes/alerts.tsx",
		children: void 0,
		preloads: [
			"/assets/alerts-DWT8hJxB.js",
			"/assets/card-Zhmq5vvW.js",
			"/assets/waves-YyUgmF0E.js",
			"/assets/button-vtSaG0Jz.js"
		]
	},
	"/device": {
		filePath: "/workspace/src/routes/device.tsx",
		children: void 0,
		preloads: [
			"/assets/device-BpInT__M.js",
			"/assets/card-Zhmq5vvW.js",
			"/assets/button-vtSaG0Jz.js",
			"/assets/switch-C54ieM04.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-WCEhX5a0.js",
			"/assets/card-Zhmq5vvW.js",
			"/assets/button-vtSaG0Jz.js",
			"/assets/switch-C54ieM04.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
